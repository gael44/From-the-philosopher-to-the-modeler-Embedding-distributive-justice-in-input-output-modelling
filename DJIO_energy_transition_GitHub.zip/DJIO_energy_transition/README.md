# DJ/IO: distributive justice assessment of EU electricity decarbonisation scenarios

Code and data for the article *From the philosopher to the modeler: Embedding distributive justice
in input–output modelling* by Gaël Croué, Anna Melnyk and Franco Donati.

The Distributive Justice/Input–Output (DJ/IO) framework evaluates footprints computed with an
input–output model against benchmark distributions derived from theories of distributive justice.
This repository applies it to two EU electricity decarbonisation pathways (EU Reference Scenario
2016 and Stanford WWS, as implemented by Černý et al., 2022) in EXIOBASE 3.7 (2015, industry by
industry). It uses three benchmarks: sufficientarian (decent living standards), egalitarian (equal
share per person) and liberal egalitarian (tax-and-transfer). It covers two currencies
(consumption-based CO2 and blue water footprints) and two scopes (the 27 EU member states; the EU27
as one actor plus the 22 other EXIOBASE regions).

## Quick start

```
pip install -r requirements.txt
# put EXIOBASE 3.7 ixi 2015 (unzipped) in data/raw/exiobase/IOT_2015_ixi/  (see data/README.md)
python run_all.py            # scripts 01-08 in order, about 15 minutes, 3 GB of RAM
python tests/run_tests.py    # optional: null test and full run on synthetic data (2 minutes)
```

`data/raw/exiobase/IOT_2015_ixi/` must contain `A.txt`, `Y.txt`, `unit.txt` and the `satellite/`
folder directly. On Windows, a short path outside synchronised folders (for example
`C:\DJIO\DJIO_energy_transition`) avoids path-length and file-syncing problems.

Every path, data choice and normative parameter is in `config.py`. Change a choice there and
rerun `run_all.py`; all tables and figures follow. `python run_all.py 4` reruns scripts 04-08 only,
for changes that do not touch the electricity scenarios.

## Folder structure

```
DJIO_energy_transition/
├── README.md                this file
├── CITATION.cff             how to cite this repository
├── LICENSE                  MIT (code)
├── LICENSE-DATA             CC BY 4.0 (processed data and results)
├── requirements.txt
├── config.py                all paths, data choices and normative parameters
├── run_all.py               runs scripts 01-08 in order
├── scripts/                 main scripts (reference implementation)
│   ├── 01_population.py               UN WPP 2024 -> population of the 49 regions, 2015
│   ├── 02_dls_prices.py               Comtrade 2015 import unit values of the DLS items
│   ├── 03_electricity_scenarios.py    electricity data processing, BAU + scenarios, footprints
│   ├── 04_sufficiency_threshold.py    decent-living (DLS) footprint per region and model scenario
│   ├── 05_justice_references.py       egalitarian budget, liberal egalitarian references
│   ├── 06_indicators_tables_figures.py  indicators, sensitivities, Theil, radar chart
│   ├── 07_validation.py               balances, conservation, comparison with literature
│   ├── 08_export_tables.py            reader-friendly inputs + Supplementary Data workbook
│   └── djio_functions.py              shared functions (scopes, references, distances)
├── step_by_step/            the same model written step by step with pandas, for reading;
│                             gives identical results (see step_by_step/README.md)
├── tests/                   null test and full run on synthetic data
├── data/
│   ├── README.md            sources, licences, how to obtain each input
│   ├── raw/                 inputs as obtained (EXIOBASE and Comtrade not included)
│   └── processed/           population, prices, DLS basket, generation mixes, proxies (CSV)
└── results/
    ├── tables/              every table of the article and Supplementary Data (CSV)
    ├── figures/             radar chart (PNG, PDF)
    ├── DJIO_SI_tables.xlsx  Supplementary Data 1 (Tables S1-S18)
    ├── validation_report.txt
    ├── footprints/          consumption, territorial, EU27 by region of emission (CSV)
    ├── references/          SF, EG, LE references and the budget (CSV)
    └── multipliers/         multipliers per model scenario, total output (CSV; Zenodo archive)
```

## Where the article's results come from

| Article | File |
|---|---|
| Table 5 (indicators, with absolute distances) | results/tables/indicators.csv |
| Table 6 (actors moving closer / further) | results/tables/country_changes.csv |
| Figure 6 (radar, with sensitivity ranges) | results/figures/fig_radar.png |
| Theil decomposition | results/tables/theil_decomposition.csv |
| EU footprint inside vs outside the EU | results/tables/eu_footprint_by_origin.csv |
| Sensitivity analyses | results/tables/sensitivity_*.csv |
| Validation | results/validation_report.txt, results/tables/validation_*.csv |
| Supplementary Data 1 (Tables S1-S18) | results/DJIO_SI_tables.xlsx |

## Main modelling choices (all in config.py)

- Consumption-based footprints including household direct emissions; CO2 includes biogenic
  waste CO2; blue water consumption.
- Five processing steps for EXIOBASE electricity data: zero-output intensities, near-empty
  electricity technologies, CO2 booked on non-combustion technologies, power-plant CO2 booked
  under steam and hot water supply, and the EU split of electricity CO2 by emission factors
  (Supplementary Information, Section S3).
- Electricity mix by generation (GWh); BAU built with the same procedure (2015 mix).
- Egalitarian budget per person: 1.61 t CO2 (planetary-boundary share) and 159 m3 blue water
  (2015 world average).
- Liberal egalitarian: 50% tax above the budget, transfers to actors below it, equal dividend
  per person; within each scope and each model scenario. A priority-based variant (Casal, 2011)
  is a sensitivity analysis.
- Sufficientarian: DLS footprint with each model scenario's technology, 2015 Comtrade prices,
  origin by import structure with a capacity check; mobility not priced (the threshold is a
  lower bound).
- Indicators: population-weighted root-mean-square distances, ratio to BAU (1 = no change).

In the code, a *state* is one of the three model runs: `baseline` (BAU, 2015 electricity mix),
`euref` and `stanford` (2050 mixes). The article calls these *model scenarios*.

## Data availability

EXIOBASE 3.7 is available at https://doi.org/10.5281/zenodo.3583071 (Stadler et al., 2018). UN
Comtrade data can be retrieved from https://comtradeplus.un.org with the query documented in
`data/README.md`. The electricity scenarios are from Černý et al. (2022). Neither EXIOBASE nor the
raw Comtrade files are redistributed here; see `data/README.md` for sources and licences.

## How to cite

Please cite the article and this repository (see `CITATION.cff`).

## Licence

Code: MIT (LICENSE). Processed data and results: CC BY 4.0 (LICENSE-DATA). Third-party inputs
keep their own licences (data/README.md).
