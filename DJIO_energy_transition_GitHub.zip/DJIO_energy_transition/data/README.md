# Data: sources, licences and how to obtain each input

| Input | Where it goes | Source | Licence / redistribution | Included in the repository? |
|---|---|---|---|---|
| EXIOBASE 3.7, IOT 2015 ixi (A.txt, Y.txt, satellite/F.txt, F_hh.txt, unit.txt) | `raw/exiobase/IOT_2015_ixi/` | Stadler et al. (2018), J. Ind. Ecol. 22, 502-515; https://doi.org/10.5281/zenodo.3583071 (file `IOT_2015_ixi.zip`) | CC BY-SA 4.0 | No: download and unzip |
| Electricity generation by country and technology, 2015 and 2050 (`Scenarios.xlsx`) | `raw/scenarios/` | Černý et al. (2022), https://doi.org/10.2139/ssrn.4013339; github.com/Xcerm01/Employment_Electricity_EU (unmodified file) | as stated in the source repository | Yes (cite the source) |
| Proxy countries for technologies absent in 2015 | `raw/scenarios/technical_coefficient_substitution_Cerny2022.xlsx`; CSV in `processed/` | Černý et al. (2022), Section 8.3; table compiled by the authors | CC BY 4.0 (this table) | Yes |
| DLS requirements, HS codes and EXIOBASE mapping (`DLS_requirements_Exiobase.xlsx`) | `raw/dls/` | Quantities: Vélez-Henao & Pauliuk (2023), ES&T 57, 14206-14217 (CC BY 4.0); mapping by the authors | CC BY 4.0 | Yes |
| UN Comtrade 2015 imports | `raw/comtrade/` (xlsx or csv) | comtradeplus.un.org: HS codes in `processed/dls_basket_2015.csv` (column HS_used), period 2015, all reporters, partner World, 2nd partner World, flow Imports, mode of transport TOTAL, customs procedure TOTAL | UN Comtrade terms of use: raw files not redistributed | No (query above); derived prices in `processed/DLS_prices_2015.csv` |
| Population, 1 January 2015 | `processed/pop_2015_exiobase.csv` (made by script 01 from `raw/population/WPP2024_Demographic_Indicators_Medium.csv`) | UN DESA (2024), World Population Prospects 2024 | CC BY 3.0 IGO | Processed file yes; raw file: download |

## Processed files (made by the scripts, CC BY 4.0)

| File | Made by | Content |
|---|---|---|
| `pop_2015_exiobase.csv` | 01 | Population of the 49 EXIOBASE regions on 1 January 2015 |
| `DLS_prices_2015.csv` | 02 | World import unit value per HS code, EUR 2015 per DLS unit, number of importers |
| `dls_basket_2015.csv` | 08 | DLS items per person: quantity, HS code used, price and its source, EUR per year, EXIOBASE sector |
| `generation_mix_2015_2050.csv` | 08 | GWh by EU country and technology, 2015 and 2050, both scenarios |
| `proxy_recipes_Cerny2022.csv` | 08 | Proxy country per missing technology and scenario |
