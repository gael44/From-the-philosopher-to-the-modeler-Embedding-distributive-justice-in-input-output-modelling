# -*- coding: utf-8 -*-
"""
01_population.py
UN World Population Prospects 2024 (population on 1 January 2015) aggregated to the
49 EXIOBASE regions.  Output: data/processed/pop_2015_exiobase.csv
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import pandas as pd
import config as cfg

#%% WPP country -> EXIOBASE region

country_to_exio = {
    # --- Africa ---
    'Algeria': 'WA', 'Angola': 'WA', 'Benin': 'WA', 'Botswana': 'WA', 'Burkina Faso': 'WA',
    'Burundi': 'WA', 'Cabo Verde': 'WA', 'Cameroon': 'WA', 'Central African Republic': 'WA',
    'Chad': 'WA', 'Comoros': 'WA', 'Congo': 'WA', 'Democratic Republic of the Congo': 'WA',
    'Côte d\'Ivoire': 'WA', 'Djibouti': 'WA', 'Egypt': 'WA', 'Equatorial Guinea': 'WA',
    'Eritrea': 'WA', 'Eswatini': 'WA', 'Ethiopia': 'WA', 'Gabon': 'WA', 'Gambia': 'WA',
    'Ghana': 'WA', 'Guinea': 'WA', 'Guinea-Bissau': 'WA', 'Kenya': 'WA', 'Lesotho': 'WA',
    'Liberia': 'WA', 'Libya': 'WA', 'Madagascar': 'WA', 'Malawi': 'WA', 'Mali': 'WA',
    'Mauritania': 'WA', 'Mauritius': 'WA', 'Mayotte': 'WA', 'Morocco': 'WA', 'Mozambique': 'WA',
    'Namibia': 'WA', 'Niger': 'WA', 'Nigeria': 'WA', 'Réunion': 'WA', 'Rwanda': 'WA',
    'Sao Tome and Principe': 'WA', 'Senegal': 'WA', 'Seychelles': 'WA', 'Sierra Leone': 'WA',
    'Somalia': 'WA', 'South Sudan': 'WA', 'Sudan': 'WA', 'Togo': 'WA',
    'Tunisia': 'WA', 'Uganda': 'WA', 'United Republic of Tanzania': 'WA', 'Zambia': 'WA',
    'Zimbabwe': 'WA', 'South Africa': 'ZA', 'Western Sahara': 'WA', 'Saint Helena': 'WA',

    # --- Europe (specific countries have their own region codes) ---
    'Austria': 'AT', 'Belgium': 'BE', 'Bulgaria': 'BG', 'Cyprus': 'CY', 'Czechia': 'CZ',
    'Germany': 'DE', 'Denmark': 'DK', 'Estonia': 'EE', 'Spain': 'ES', 'Finland': 'FI',
    'France': 'FR', 'Greece': 'GR', 'Croatia': 'HR', 'Hungary': 'HU', 'Ireland': 'IE',
    'Italy': 'IT', 'Lithuania': 'LT', 'Luxembourg': 'LU', 'Latvia': 'LV', 'Malta': 'MT',
    'Netherlands': 'NL', 'Poland': 'PL', 'Portugal': 'PT', 'Romania': 'RO', 'Sweden': 'SE',
    'Slovenia': 'SI', 'Slovakia': 'SK', 'United Kingdom': 'GB', 'Switzerland': 'CH', 'Norway': 'NO',

    # --- Rest of Europe (WE) ---
    'Albania': 'WE', 'Andorra': 'WE', 'Bosnia and Herzegovina': 'WE', 'Faroe Islands': 'WE',
    'Gibraltar': 'WE', 'Guernsey': 'WE', 'Holy See': 'WE', 'Iceland': 'WE', 'Isle of Man': 'WE',
    'Jersey': 'WE', 'Kosovo (under UNSC res. 1244)': 'WE', 'Liechtenstein': 'WE',
    'Monaco': 'WE', 'Montenegro': 'WE', 'North Macedonia': 'WE', 'San Marino': 'WE',
    'Serbia': 'WE', 'Belarus':'WE', 'Republic of Moldova':'WE', 'Ukraine':'WE','Greenland':'DK',

    # --- Americas ---
    'United States of America': 'US', 'Canada': 'CA', 'Mexico': 'MX', 'Brazil': 'BR',

    # --- Rest of Latin America (WL) ---
    'Anguilla': 'WL', 'Antigua and Barbuda': 'WL', 'Aruba': 'WL', 'Bahamas': 'WL', 'Barbados': 'WL',
    'Belize': 'WL', 'Bermuda': 'WL', 'Bolivia (Plurinational State of)': 'WL', 'Bonaire, Sint Eustatius and Saba': 'WL',
    'British Virgin Islands': 'WL', 'Cayman Islands': 'WL', 'Chile': 'WL', 'Colombia': 'WL', 'Costa Rica': 'WL',
    'Cuba': 'WL', 'Curaçao': 'WL', 'Dominica': 'WL', 'Dominican Republic': 'WL', 'Ecuador': 'WL',
    'El Salvador': 'WL', 'Falkland Islands (Malvinas)': 'WL', 'French Guiana': 'WL', 'Grenada': 'WL',
    'Guadeloupe': 'WL', 'Guatemala': 'WL', 'Guyana': 'WL', 'Haiti': 'WL', 'Honduras': 'WL',
    'Jamaica': 'WL', 'Martinique': 'WL', 'Montserrat': 'WL', 'Nicaragua': 'WL', 'Panama': 'WL',
    'Paraguay': 'WL', 'Peru': 'WL', 'Puerto Rico': 'WL', 'Saint Barthélemy': 'WL',
    'Saint Kitts and Nevis': 'WL', 'Saint Lucia': 'WL', 'Saint Martin (French part)': 'WL',
    'Saint Vincent and the Grenadines': 'WL', 'Sint Maarten (Dutch part)': 'WL',
    'Suriname': 'WL', 'Trinidad and Tobago': 'WL', 'Turks and Caicos Islands': 'WL',
    'Uruguay': 'WL', 'Venezuela (Bolivarian Republic of)': 'WL', 'Argentina':'WL', 
    'United States Virgin Islands': 'WL','Saint Pierre and Miquelon':'WL',
    # --- Asia (specific countries) ---
    'Japan': 'JP', 'China': 'CN', 'Republic of Korea': 'KR', 'China, Taiwan Province of China': 'TW',
    'Indonesia': 'ID', 'India': 'IN', 'Australia': 'AU',

    # --- Rest of Asia (WF) ---
    'Afghanistan': 'WF', 'Armenia': 'WF', 'Azerbaijan': 'WF', 'Bangladesh': 'WF', 'Bhutan': 'WF',
    'Brunei Darussalam': 'WF', 'Cambodia': 'WF', 'China, Hong Kong SAR': 'WF', 'China, Macao SAR': 'WF',
    'Dem. People\'s Republic of Korea': 'WF', 'Georgia': 'WF', 'Kazakhstan': 'WF', 'Kyrgyzstan': 'WF',
    'Lao People\'s Democratic Republic': 'WF', 'Malaysia': 'WF', 'Maldives': 'WF', 'Mongolia': 'WF',
    'Myanmar': 'WF', 'Nepal': 'WF', 'Pakistan': 'WF', 'Philippines': 'WF', 'Singapore': 'WF',
    'Sri Lanka': 'WF', 'Tajikistan': 'WF', 'Thailand': 'WF', 'Timor-Leste': 'WF', 'Turkmenistan': 'WF',
    'Uzbekistan': 'WF', 'Viet Nam': 'WF',

    # --- Middle East (WM) ---
    'Bahrain': 'WM', 'Iran (Islamic Republic of)': 'WM', 'Iraq': 'WM', 'Israel': 'WM', 'Jordan': 'WM',
    'Kuwait': 'WM', 'Lebanon': 'WM', 'Oman': 'WM', 'Qatar': 'WM', 'Saudi Arabia': 'WM',
    'State of Palestine': 'WM', 'Syrian Arab Republic': 'WM', 'Türkiye': 'TR', 'United Arab Emirates': 'WM',
    'Yemen': 'WM',

    # --- Oceania (AU) ---
    'New Zealand': 'WF', 'Fiji': 'WF', 'New Caledonia': 'WF', 'Papua New Guinea': 'WF',
    'Solomon Islands': 'WF', 'Vanuatu': 'WF', 'Guam': 'WF', 'Kiribati': 'WF', 'Marshall Islands': 'WF',
    'Micronesia (Fed. States of)': 'WF', 'Nauru': 'WF', 'Northern Mariana Islands': 'WF', 'Palau': 'WF',
    'American Samoa': 'WF', 'Cook Islands': 'WF', 'French Polynesia': 'WF', 'Niue': 'WF',
    'Samoa': 'WF', 'Tokelau': 'WF', 'Tonga': 'WF', 'Tuvalu': 'WF', 'Wallis and Futuna Islands': 'WF',

    # --- Russia ---
    'Russian Federation': 'RU'
}

#%% Aggregate

wpp = pd.read_csv(cfg.WPP_FILE, low_memory=False)
pop = wpp.loc[(wpp['Time'] == cfg.YEAR) & wpp['ISO3_code'].notna(), ['Location', 'TPopulation1Jan']].copy()
pop['TPopulation1Jan'] *= 1000                                # thousands -> persons
pop['region'] = pop['Location'].map(country_to_exio)

unmapped = pop.loc[pop['region'].isna(), 'Location'].tolist()
if unmapped:
    print(f'{len(unmapped)} WPP countries not mapped (dropped):', unmapped)

pop = pop.dropna(subset=['region']).groupby('region')['TPopulation1Jan'].sum().sort_index()
assert len(pop) == 49, f'expected 49 EXIOBASE regions, got {len(pop)}'

cfg.PROCESSED.mkdir(parents=True, exist_ok=True)
pop.to_csv(cfg.POP_FILE)
print('Saved', cfg.POP_FILE, '| world population:', round(pop.sum() / 1e9, 3), 'bn')
