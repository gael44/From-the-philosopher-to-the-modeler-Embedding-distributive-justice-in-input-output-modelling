# -*- coding: utf-8 -*-
"""
02_dls_prices.py
World import unit values (2015) of the DLS commodities from UN Comtrade, in EUR per DLS unit.

Download (comtradeplus.un.org): HS codes of the DLS items, period 2015, all reporters,
partner World, 2nd partner World, flow Imports, transport mode TOTAL, customs TOTAL.
Save the files in data/raw/comtrade/ (.xlsx or .csv; several files are combined).

Method, per HS code
1. One row per importer (partner World); rows with a value and a quantity (or net weight).
2. Basis: the Comtrade quantity, or the net weight (kg) when the DLS item is in kg but Comtrade
   counts heads or pieces (live animals, T-shirts, bricks); cfg.DLS_PRICE_BASIS.
3. Trim unit values 1% each side, then quantity-weighted mean = total value / total quantity.
4. USD -> EUR (2015 average) and Comtrade unit -> DLS unit (cfg.DLS_UNIT_FACTOR: e.g. concrete
   EUR/kg x 2400 kg/m3, electricity EUR/MWh / 1000).
Output: data/processed/DLS_prices_2015.csv (EUR per DLS unit, by HS code). Script 04 uses it.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import pandas as pd
import config as cfg

files = sorted(cfg.COMTRADE_DIR.glob('*.xlsx')) + sorted(cfg.COMTRADE_DIR.glob('*.csv'))
read = lambda f: pd.read_excel(f) if f.suffix == '.xlsx' else pd.read_csv(f, encoding='latin-1', low_memory=False)
trade = pd.concat([read(f) for f in files], ignore_index=True).drop_duplicates()
print(f'{len(files)} Comtrade files, {len(trade)} rows')

#%% Imports of the study year, partner World (one row per importer)
trade = trade[(trade['flowCode'] == 'M') & (trade['refYear'] == cfg.YEAR) & (trade['partnerCode'] == 0)].copy()
trade['cmdCode'] = trade['cmdCode'].astype(int)

rows = []
for hs, g in trade.groupby('cmdCode'):
    basis = cfg.DLS_PRICE_BASIS.get(hs, 'qty')
    g = g[(g[basis] > 0) & (g['primaryValue'] > 0)].copy()
    g['p'] = g['primaryValue'] / g[basis]
    lo, hi = g['p'].quantile([0.01, 0.99])
    g = g[(g['p'] >= lo) & (g['p'] <= hi)]
    eur = g['primaryValue'].sum() / g[basis].sum() * cfg.EUR_PER_USD
    rows.append({'HS': hs, 'cmdDesc': g['cmdDesc'].iloc[0],
                 'comtrade_unit': 'kg' if basis == 'netWgt' else g['qtyUnitAbbr'].mode().iloc[0],
                 'EUR_per_comtrade_unit': eur, 'factor_to_DLS_unit': cfg.DLS_UNIT_FACTOR.get(hs, 1.0),
                 'EUR_per_DLS_unit': eur * cfg.DLS_UNIT_FACTOR.get(hs, 1.0), 'n_importers': len(g)})
prices = pd.DataFrame(rows).set_index('HS')
cfg.PROCESSED.mkdir(parents=True, exist_ok=True)
prices.to_csv(cfg.PRICES_FILE)
print(prices[['comtrade_unit', 'EUR_per_DLS_unit', 'n_importers']].round(4).to_string())
