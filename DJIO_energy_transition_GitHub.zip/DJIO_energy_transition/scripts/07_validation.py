# -*- coding: utf-8 -*-
"""
07_validation.py
Checks that the numbers are plausible BEFORE interpreting them.
1. Global balance: sum of consumption footprints = sum of territorial emissions (each state).
2. LE references conserve the total footprint of each scope.
3. BAU per-capita footprints (consumption and territorial) for every region -> compare with
   published EXIOBASE-based footprints (column left for literature values).
4. DLS footprint per person (CO2, water, energy) -> table of comparable literature values
   (cfg.DLS_LITERATURE), stating mobility, technology year and energy type of each.
Output: results/tables/validation_*.csv and results/validation_report.txt
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import numpy as np
import pandas as pd
import config as cfg
from djio_functions import read_series, to_scope, load_dls_basket

lines = []
def say(*a):
    msg = ' '.join(str(x) for x in a); print(msg); lines.append(msg)

pop = read_series(cfg.POP_FILE)
conv = cfg.TO_BUDGET_UNIT

#%% 1. Global balance
say('1. Global balance: consumption-based total vs territorial total')
for state in cfg.STATES:
    for u in cfg.CURRENCIES:
        c = read_series(cfg.FOOTPRINTS / 'consumption' / f'FP_{state}_{u}.csv').sum()
        t = read_series(cfg.FOOTPRINTS / 'territorial' / f'FP_{state}_{u}.csv').sum()
        say(f'   {state:9s} {u:6s} consumption {c * conv[u]:.4e}  territorial {t * conv[u]:.4e}  rel. diff {abs(c / t - 1):.2e}')

#%% 2. LE conservation
say('2. LE references conserve totals')
worst = 0
for sc in cfg.SCOPES:
    for u in cfg.CURRENCIES:
        for state in cfg.STATES:
            F = to_scope(read_series(cfg.FOOTPRINTS / 'consumption' / f'FP_{state}_{u}.csv') * conv[u], sc, cfg.EU27)
            R = read_series(cfg.REFERENCES / 'le' / f'LE_{state}_{u}_{sc}.csv')
            worst = max(worst, abs(R.sum() / F.sum() - 1))
say(f'   largest relative deviation: {worst:.2e}')

#%% 3. BAU per-capita footprints
tab = pd.DataFrame({
    'pop_million': pop / 1e6,
    'CO2_consumption_t_pc': read_series(cfg.FOOTPRINTS / 'consumption' / 'FP_baseline_co2.csv') * conv['co2'] / pop,
    'CO2_territorial_t_pc': read_series(cfg.FOOTPRINTS / 'territorial' / 'FP_baseline_co2.csv') * conv['co2'] / pop,
    'water_consumption_m3_pc': read_series(cfg.FOOTPRINTS / 'consumption' / 'FP_baseline_water.csv') * conv['water'] / pop,
    'water_territorial_m3_pc': read_series(cfg.FOOTPRINTS / 'territorial' / 'FP_baseline_water.csv') * conv['water'] / pop})
tab['CO2_published_t_pc'] = np.nan          # fill from literature (e.g. EXIOBASE-based studies, 2015)
cfg.TABLES.mkdir(parents=True, exist_ok=True)
tab.round(3).to_csv(cfg.TABLES / 'validation_bau_per_capita.csv')
eu = tab.loc[cfg.EU27]
w = eu['pop_million'] / eu['pop_million'].sum()
say('3. BAU per-capita footprints')
say(f'   EU27 CO2 consumption: mean {(w * eu.CO2_consumption_t_pc).sum():.1f} t, range '
    f'{eu.CO2_consumption_t_pc.min():.1f} ({eu.CO2_consumption_t_pc.idxmin()}) - {eu.CO2_consumption_t_pc.max():.1f} ({eu.CO2_consumption_t_pc.idxmax()})')
say(f'   EU27 CO2 territorial: mean {(w * eu.CO2_territorial_t_pc).sum():.1f} t   (EU imports embodied CO2 if consumption > territorial)')
say(f'   EU27 blue water consumption: mean {(w * eu.water_consumption_m3_pc).sum():.0f} m3')
wo = tab.pop_million / tab.pop_million.sum()
say(f'   World: CO2 {(wo * tab.CO2_consumption_t_pc).sum():.2f} t, blue water {(wo * tab.water_consumption_m3_pc).sum():.0f} m3 per person')

#%% 4. DLS footprint per person
say('4. DLS footprint per person (baseline technology)')
dls = load_dls_basket(cfg, verbose=False)
gas_m3 = float(dls.loc[dls['ReferenceProduct'] == cfg.DLS_GAS_ITEM, 'Quantity'].sum())
Y_DLS = pd.read_csv(cfg.REFERENCES / 'sf' / 'Y_DLS.csv', index_col=[0, 1])
res = {}
for u in ['co2', 'water', 'energy'] + list(cfg.ENERGY_PART_KEYWORDS):
    f = cfg.MULTIPLIERS / f'M_baseline_{u}.csv'
    if not f.exists():
        continue
    M = pd.read_csv(f, index_col=[0, 1]).iloc[:, 0]
    res[u] = pd.Series(M.values @ Y_DLS.loc[M.index].values, index=Y_DLS.columns) / pop.reindex(Y_DLS.columns)
gas_GJ = gas_m3 * cfg.DLS_GAS_GJ_PER_M3
dls_pc = pd.DataFrame({'CO2_t_pc': res['co2'] * conv['co2'] + gas_m3 * cfg.GAS_EF_KG_PER_M3 / 1000,
                       'water_m3_pc': res['water'] * conv['water'],
                       'energy_GJ_pc': res['energy'] * 1000 + gas_GJ})   # TJ -> GJ
if all(k in res for k in cfg.ENERGY_PART_KEYWORDS):     # closer to final energy: minus losses, feedstocks
    dls_pc['energy_excl_losses_nonenergy_GJ_pc'] = (res['energy'] - res['energy_nene'] - res['energy_loss']) * 1000 + gas_GJ
dls_pc.round(3).to_csv(cfg.TABLES / 'validation_dls_per_capita.csv')
wpop = pop.reindex(dls_pc.index) / pop.reindex(dls_pc.index).sum()
for col in dls_pc:
    say(f'   {col:14s} world mean {(wpop * dls_pc[col]).sum():8.2f}  range {dls_pc[col].min():.2f} - {dls_pc[col].max():.2f}')

# Comparable literature values (what each includes is what makes them comparable or not)
ours = {c: (wpop * dls_pc[c]).sum() for c in dls_pc}
rng = {c: f'{dls_pc[c].min():.1f}-{dls_pc[c].max():.1f}' for c in dls_pc}
L = []
add = lambda *r: L.append(dict(zip(['Study', 'Quantity', 'Value_per_capita', 'Regional_range', 'Mobility',
                                    'Technology', 'Energy_type', 'Comparable_to_ours'], r)))
add('This study', 'Energy, EXIOBASE net', round(ours['energy_GJ_pc'], 1), rng['energy_GJ_pc'], 'excluded',
    '2015 (EXIOBASE 3.7)', 'net = final + losses + non-energy use', '-')
if 'energy_excl_losses_nonenergy_GJ_pc' in ours:
    c = 'energy_excl_losses_nonenergy_GJ_pc'
    add('This study', 'Energy, net minus losses and non-energy use', round(ours[c], 1), rng[c], 'excluded',
        '2015 (EXIOBASE 3.7)', 'close to final energy', '-')
add('This study', 'CO2', round(ours['CO2_t_pc'], 2), rng['CO2_t_pc'], 'excluded', '2015', 't CO2', '-')
add('This study', 'Blue water', round(ours['water_m3_pc'], 0), rng['water_m3_pc'], 'excluded', '2015', 'm3', '-')
for r in cfg.DLS_LITERATURE:
    add(*r)
lit = pd.DataFrame(L)
lit.to_csv(cfg.TABLES / 'validation_dls_literature.csv', index=False)
say('   Comparison with the literature (results/tables/validation_dls_literature.csv):')
for _, r in lit.iterrows():
    say(f"   {r.Study:32s} {r.Quantity:45s} {r.Value_per_capita!s:>6}  range {r.Regional_range:10s} mobility {r.Mobility}")

(cfg.RESULTS / 'validation_report.txt').write_text('\n'.join(lines))
