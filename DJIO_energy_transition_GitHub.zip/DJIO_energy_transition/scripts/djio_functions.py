# -*- coding: utf-8 -*-
"""
djio_functions.py - functions shared by scripts 05 and 06: scopes, justice references, distances.
All inputs are pandas Series indexed by region, in the units of the per-capita budgets (t, m3).
"""
import numpy as np
import pandas as pd


def load_dls_basket(cfg, verbose=True):
    """DLS items per person with the price actually used (EUR per DLS unit) and its source.
    Prices: Comtrade 2015 (script 02) when available, else the DLS sheet's own price."""
    dls = pd.read_excel(cfg.DLS_FILE, sheet_name='DLS-Exiobase', header=1)
    dls = dls.loc[:, ~dls.columns.astype(str).str.contains('^Unnamed')]
    dls['HS_used'] = dls['ReferenceProduct'].map(cfg.DLS_HS_FIX).fillna(dls['HS'])
    dls['price_source'] = np.where(dls['HS'].notna(), 'DLS sheet', 'no HS code: sheet value kept')
    if cfg.USE_COMTRADE_2015_PRICES and cfg.PRICES_FILE.exists():
        prices = pd.read_csv(cfg.PRICES_FILE, index_col=0)['EUR_per_DLS_unit']
        new = dls['HS_used'].map(prices)
        keep = dls['ReferenceProduct'].isin(cfg.DLS_KEEP_SHEET_PRICE) | new.isna()
        dls['Price'] = new.where(~keep, dls['Price'])
        dls.loc[~keep, 'price_source'] = 'Comtrade 2015'
        dls['Values'] = (dls['Quantity'] * dls['Price']).where(dls['HS'].notna(), dls['Values'])
        if verbose:
            for item in dls.loc[keep & (dls['Quantity'] > 0) & dls['HS'].notna(), 'ReferenceProduct']:
                print(f'  sheet price kept for: {item} ({cfg.DLS_KEEP_SHEET_PRICE.get(item, "HS code not in the download")})')
    if verbose:
        unpriced = dls[(dls['Quantity'] > 0) & (dls['Values'].fillna(0) == 0)]
        print(f'{len(unpriced)} DLS items with a quantity but no price (excluded):', unpriced['ReferenceProduct'].tolist())
    return dls


def read_series(path):
    s = pd.read_csv(path, index_col=0).iloc[:, 0]
    s.index = s.index.astype(str)
    return s.astype(float)


def to_scope(s, scope, eu):
    """Totals per region -> totals per actor of the scope.
    'EU': the 27 member states.  'EUROW': EU27 summed into one actor + all other regions."""
    if scope == 'EU':
        return s.loc[eu]
    if scope == 'EUROW':
        return pd.concat([pd.Series({'EU27': s.loc[eu].sum()}), s.drop(index=eu)])
    raise ValueError(scope)


#%% Justice references --------------------------------------------------------------------

def budget_per_capita(rule, pb_pc, world_avg_pc):
    """Equal-share budget per person. 'binding': the smaller of the planetary-boundary share and
    today's world average; 'planetary_boundary'; 'current_world_average'."""
    if rule == 'binding':
        return min(pb_pc, world_avg_pc)
    if rule == 'planetary_boundary':
        return pb_pc
    if rule == 'current_world_average':
        return world_avg_pc
    raise ValueError(rule)


def egalitarian_reference(pop, budget_pc):
    """Everyone receives the same per-capita budget."""
    return pop * budget_pc


def liberal_egalitarian_reference(F, pop, threshold_pc, tax_rate=0.5, surplus_rule='per_capita'):
    """Tax-and-transfer institution inside ONE scope; conserves the total footprint.
    1. threshold T_i = threshold_pc x P_i
    2. tax_i = tax_rate x max(0, F_i - T_i)            (only actors above T pay)
    3. shortfalls max(0, T_i - F_i) are closed by the fund (pro rata if it is too small)
    4. surplus -> equal per-capita dividend ('per_capita') or back to payers ('contributors')
    5. R_i = F_i - tax_i + transfer_i + dividend_i"""
    T = pop * threshold_pc
    excess, shortfall = (F - T).clip(lower=0), (T - F).clip(lower=0)
    tax = tax_rate * excess
    revenue, need = tax.sum(), shortfall.sum()
    if need == 0:
        transfer, surplus = shortfall * 0, revenue
    elif revenue >= need:
        transfer, surplus = shortfall, revenue - need
    else:
        transfer, surplus = shortfall * revenue / need, 0.0
    if surplus_rule == 'per_capita':
        dividend = surplus * pop / pop.sum()
    elif surplus_rule == 'contributors':
        dividend = surplus * tax / tax.sum() if tax.sum() > 0 else tax * 0
    else:
        raise ValueError(surplus_rule)
    R = F - tax + transfer + dividend
    assert np.isclose(R.sum(), F.sum()), 'LE redistribution does not conserve the total'
    return R


def casal_rate(F, pop, threshold_pc):
    """Share of the footprint above the threshold that would have to be removed for the scope's
    total to fit its budget (Casal 2011: 'the minimal tax rate necessary to reduce consumption to
    the appropriate level'). 0 = already within budget, 1 = every unit above the threshold."""
    T = pop * threshold_pc
    excess = (F - T).clip(lower=0).sum()
    overshoot = F.sum() - T.sum()
    return float(np.clip(overshoot / excess, 0, 1)) if excess > 0 else 0.0


def casal_reference(F, pop, threshold_pc, tax_rate, eta=1.0):
    """Global Share variant (Casal 2011): tax on the footprint above the threshold, revenue shared
    by PRIORITY with no cut-off: weight_i = P_i x (per-capita footprint_i)^-eta, so the lower an
    actor's footprint per person, the larger its share per person. Conserves the total."""
    T = pop * threshold_pc
    tax = tax_rate * (F - T).clip(lower=0)
    w = pop * (F / pop) ** (-eta)
    R = F - tax + tax.sum() * w / w.sum()
    assert np.isclose(R.sum(), F.sum()), 'Casal redistribution does not conserve the total'
    return R


#%% Distances -----------------------------------------------------------------------------

def weights(P, weighting):
    if weighting == 'population':
        return P / P.sum()                       # each person counts once
    if weighting == 'country':
        return P * 0 + 1 / len(P)                # each actor counts once
    raise ValueError(weighting)


def rmsd(F, R, P, weighting='population'):
    """Weighted root-mean-square deviation of per-capita values from the reference
    (a standard deviation computed around the justice reference instead of the mean)."""
    w = weights(P, weighting)
    return float(np.sqrt((w * ((F - R) / P) ** 2).sum()))


def level_dispersion(F, R, P, weighting='population'):
    """rmsd^2 = level^2 + dispersion^2  (level = mean gap, dispersion = SD of gaps)."""
    w = weights(P, weighting)
    gap = (F - R) / P
    level = float((w * gap).sum())
    return level, float(np.sqrt((w * (gap - level) ** 2).sum()))


def sf_distance(F, S, P, weighting='population'):
    """Only shortfalls count: g = max(0, (S - F) / S); root of the weighted mean of g^2
    (Foster-Greer-Thorbecke squared gap)."""
    w = weights(P, weighting)
    g = ((S - F) / S).clip(lower=0)
    return float(np.sqrt((w * g ** 2).sum()))


def ratio(d_policy, d_bau):
    """Indicator centred on 1. 1 = as far as BAU, <1 closer, 0 = benchmark reached.
    NaN (shown as a dagger) = not defined: BAU already at the benchmark (e.g. no actor below the
    DLS threshold, or no actor above the LE threshold so nothing is redistributed)."""
    if np.isclose(d_bau, 0):
        return np.nan
    return d_policy / d_bau


def indicators(F_bau, F_pol, P, R_eg, R_le_bau, R_le_pol, S_bau=None, S_pol=None,
               weighting='population'):
    """All indicators for one scenario x currency x scope. Series must share the same index."""
    row = {}
    if S_bau is not None:
        below_bau, below_pol = set(P.index[F_bau < S_bau]), set(P.index[F_pol < S_pol])
        row.update({'SF_abs_N_BAU': len(below_bau), 'SF_abs_N_POL': len(below_pol),
                    'SF_abs_dN': len(below_bau) - len(below_pol),
                    'SF_abs_H_BAU': P[list(below_bau)].sum() / P.sum(),
                    'SF_abs_H_POL': P[list(below_pol)].sum() / P.sum(),
                    'SF_left': ', '.join(sorted(below_bau - below_pol)) or '-',
                    'SF_entered': ', '.join(sorted(below_pol - below_bau)) or '-',
                    'SF_rel': ratio(sf_distance(F_pol, S_pol, P, weighting),
                                    sf_distance(F_bau, S_bau, P, weighting)),
                    'SF_rel_D_BAU': sf_distance(F_bau, S_bau, P, weighting),
                    'SF_rel_D_POL': sf_distance(F_pol, S_pol, P, weighting)})
    lb, db = level_dispersion(F_bau, R_eg, P, weighting)
    lp, dp = level_dispersion(F_pol, R_eg, P, weighting)
    row.update({'EG': ratio(rmsd(F_pol, R_eg, P, weighting), rmsd(F_bau, R_eg, P, weighting)),
                'EG_level': ratio(abs(lp), abs(lb)), 'EG_dispersion': ratio(dp, db),
                'EG_D_BAU': rmsd(F_bau, R_eg, P, weighting), 'EG_D_POL': rmsd(F_pol, R_eg, P, weighting),
                'LE': ratio(rmsd(F_pol, R_le_pol, P, weighting), rmsd(F_bau, R_le_bau, P, weighting)),
                'LE_D_BAU': rmsd(F_bau, R_le_bau, P, weighting), 'LE_D_POL': rmsd(F_pol, R_le_pol, P, weighting)})
    return row


def country_changes(F_bau, F_pol, R_bau, R_pol, P, weighting='population'):
    """Per actor: change in |per-capita gap| and share of the BAU squared distance (Table 7)."""
    w = weights(P, weighting)
    gap_b, gap_p = (F_bau - R_bau) / P, (F_pol - R_pol) / P
    change = gap_p.abs() - gap_b.abs()
    contrib = w * gap_b ** 2
    return pd.DataFrame({'gap_pc_BAU': gap_b, 'gap_pc_POL': gap_p, 'abs_change': change,
                         'share_of_D2_BAU': contrib / contrib.sum()})


#%% Inequality decomposition --------------------------------------------------------------

def theil_decomposition(F, P, groups):
    """Population-weighted Theil T index of per-capita footprints, decomposed by group:
    T = sum_g S_g T_g (within)  +  sum_g S_g ln(mu_g / mu) (between),  S_g = group share of the total.
    F, P: totals per region (all regions); groups: dict region -> group name."""
    F, P = F[F > 0], P[F[F > 0].index]
    mu = F.sum() / P.sum()
    phi = F / P
    T = float(((P / P.sum()) * (phi / mu) * np.log(phi / mu)).sum())
    out = {'T_total': T, 'T_between': 0.0}
    g = pd.Series(groups).reindex(F.index)
    for name in g.unique():
        Fg, Pg = F[g == name], P[g == name]
        mug, Sg = Fg.sum() / Pg.sum(), Fg.sum() / F.sum()
        Tg = float(((Pg / Pg.sum()) * ((Fg / Pg) / mug) * np.log((Fg / Pg) / mug)).sum())
        out[f'T_within_{name}'] = Tg
        out[f'contrib_within_{name}'] = Sg * Tg
        out['T_between'] += Sg * np.log(mug / mu)
    out['share_between'] = out['T_between'] / T if T > 0 else np.nan
    return out
