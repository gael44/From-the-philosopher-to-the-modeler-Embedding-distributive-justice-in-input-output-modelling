# -*- coding: utf-8 -*-
"""
05_justice_references.py
Egalitarian (EG) and liberal-egalitarian (LE) references for every scope, unit and state,
from the consumption-based footprints. All outputs in t CO2 and m3 of blue water.
- EG: population x equal-share budget per person (cfg.BUDGET_RULE; independent of the state).
- LE: tax-and-transfer institution applied INSIDE each scope to each state's own footprints.
Output: results/references/{eg,le}/...csv
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import pandas as pd
import config as cfg
from djio_functions import (read_series, to_scope, egalitarian_reference, liberal_egalitarian_reference,
                            budget_per_capita)

cfg.REFERENCES.mkdir(parents=True, exist_ok=True)
pop = read_series(cfg.POP_FILE)
FP_bau = {u: read_series(cfg.FOOTPRINTS / 'consumption' / f'FP_baseline_{u}.csv') * cfg.TO_BUDGET_UNIT[u]
          for u in cfg.CURRENCIES}
BUDGET = {u: budget_per_capita(cfg.BUDGET_RULE, cfg.PB_PER_CAPITA[u], FP_bau[u].sum() / pop.sum())
          for u in cfg.CURRENCIES}
pd.Series(BUDGET, name='budget_per_capita').to_csv(cfg.REFERENCES / 'budget_per_capita.csv')
print('Equal-share budget per person (t CO2, m3 water):', {u: round(b, 2) for u, b in BUDGET.items()})
out_eg, out_le = cfg.REFERENCES / 'eg', cfg.REFERENCES / 'le'
out_eg.mkdir(parents=True, exist_ok=True)
out_le.mkdir(parents=True, exist_ok=True)

for scope in cfg.SCOPES:
    P = to_scope(pop, scope, cfg.EU27)
    for u in cfg.CURRENCIES:
        R_eg = egalitarian_reference(P, BUDGET[u])
        R_eg.rename(f'EG_{u}_{scope}').rename_axis('actor').to_csv(out_eg / f'EG_{u}_{scope}.csv')
        for state in cfg.STATES:
            F = read_series(cfg.FOOTPRINTS / 'consumption' / f'FP_{state}_{u}.csv') * cfg.TO_BUDGET_UNIT[u]
            R_le = liberal_egalitarian_reference(to_scope(F, scope, cfg.EU27), P,
                                                 BUDGET[u], cfg.LE_TAX_RATE,
                                                 cfg.LE_SURPLUS_RULE)
            R_le.rename(f'LE_{state}_{u}_{scope}').rename_axis('actor').to_csv(out_le / f'LE_{state}_{u}_{scope}.csv')
print('Saved EG and LE references in', cfg.REFERENCES)
