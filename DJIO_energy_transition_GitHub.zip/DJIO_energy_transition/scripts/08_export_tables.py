# -*- coding: utf-8 -*-
"""
08_export_tables.py
Exports the inputs and results in reader-friendly form, for the Supplementary Information and
the Zenodo archive.
1. data/processed/: the DLS basket with the prices used, the generation mixes and the proxy
   recipes as long CSV tables (the scripts themselves read the raw Excel files).
2. results/DJIO_SI_tables.xlsx: one sheet per SI table (S1-S18), with a README sheet.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import pandas as pd
import config as cfg
from djio_functions import read_series, to_scope, load_dls_basket

REGION_NAMES = {
    'AT': 'Austria', 'BE': 'Belgium', 'BG': 'Bulgaria', 'CY': 'Cyprus', 'CZ': 'Czechia', 'DE': 'Germany',
    'DK': 'Denmark', 'EE': 'Estonia', 'ES': 'Spain', 'FI': 'Finland', 'FR': 'France', 'GR': 'Greece',
    'HR': 'Croatia', 'HU': 'Hungary', 'IE': 'Ireland', 'IT': 'Italy', 'LT': 'Lithuania', 'LU': 'Luxembourg',
    'LV': 'Latvia', 'MT': 'Malta', 'NL': 'Netherlands', 'PL': 'Poland', 'PT': 'Portugal', 'RO': 'Romania',
    'SE': 'Sweden', 'SI': 'Slovenia', 'SK': 'Slovakia', 'GB': 'United Kingdom', 'US': 'United States',
    'JP': 'Japan', 'CN': 'China', 'CA': 'Canada', 'KR': 'South Korea', 'BR': 'Brazil', 'IN': 'India',
    'MX': 'Mexico', 'RU': 'Russia', 'AU': 'Australia', 'CH': 'Switzerland', 'TR': 'Turkey', 'TW': 'Taiwan',
    'NO': 'Norway', 'ID': 'Indonesia', 'ZA': 'South Africa', 'WA': 'Rest of Asia and Pacific',
    'WL': 'Rest of America', 'WE': 'Rest of Europe', 'WF': 'Rest of Africa', 'WM': 'Rest of Middle East'}

pop = read_series(cfg.POP_FILE)
conv = cfg.TO_BUDGET_UNIT
unit = {'co2': 't CO2', 'water': 'm3 blue water'}

#%% 1. Long input tables in data/processed

dls = load_dls_basket(cfg, verbose=False)
basket = dls[['ReferenceProduct', 'Unit', 'Quantity', 'HS', 'HS_used', 'Price', 'price_source', 'Values',
              'Exiobase sector']].rename(columns={
    'ReferenceProduct': 'item', 'Unit': 'unit', 'Quantity': 'quantity_per_person_year', 'HS': 'HS_sheet',
    'Price': 'EUR_per_unit', 'Values': 'EUR_per_person_year', 'Exiobase sector': 'exiobase_sector'})
basket.to_csv(cfg.PROCESSED / 'dls_basket_2015.csv', index=False)

gen = []
for sheet, scen in [('euref_det', 'EUREF'), ('stanford_det', 'Stanford')]:
    g = pd.read_excel(cfg.SCENARIOS_FILE, sheet_name=sheet)
    g = g[g['Country.Code'].isin(cfg.EU27)][['Country.Code', 'Industry.Name', 'gen2015', 'gen2050']]
    g.insert(0, 'scenario', scen)
    gen.append(g)
gen = pd.concat(gen).rename(columns={'Country.Code': 'country', 'Industry.Name': 'technology',
                                     'gen2015': 'GWh_2015', 'gen2050': 'GWh_2050'})
gen.to_csv(cfg.PROCESSED / 'generation_mix_2015_2050.csv', index=False)

prox = pd.read_excel(cfg.PROXY_FILE, sheet_name='new') if cfg.PROXY_FILE.exists() else pd.DataFrame()
prox.to_csv(cfg.PROCESSED / 'proxy_recipes_Cerny2022.csv', index=False)

#%% 2. SI workbook

def per_capita(folder, state, u):
    return read_series(cfg.FOOTPRINTS / folder / f'FP_{state}_{u}.csv') * conv[u] / pop

fp_rows = []
for state in cfg.STATES:
    for u in cfg.CURRENCIES:
        sf = read_series(cfg.REFERENCES / 'sf' / f'FP_SF_{u}_{state}.csv') * conv[u] / pop
        df = pd.DataFrame({'state': state, 'unit': unit[u],
                           'consumption_per_capita': per_capita('consumption', state, u),
                           'territorial_per_capita': per_capita('territorial', state, u),
                           'SF_threshold_per_capita': sf})
        fp_rows.append(df.rename_axis('region').reset_index())
footprints = pd.concat(fp_rows)
footprints.insert(1, 'region_name', footprints['region'].map(REGION_NAMES))

ref_rows = []
budget = read_series(cfg.REFERENCES / 'budget_per_capita.csv')
for sc in cfg.SCOPES:
    P = to_scope(pop, sc, cfg.EU27)
    for u in cfg.CURRENCIES:
        for state in cfg.STATES:
            F = to_scope(read_series(cfg.FOOTPRINTS / 'consumption' / f'FP_{state}_{u}.csv') * conv[u], sc, cfg.EU27)
            le = read_series(cfg.REFERENCES / 'le' / f'LE_{state}_{u}_{sc}.csv')
            ref_rows.append(pd.DataFrame({'scope': sc, 'state': state, 'unit': unit[u],
                                          'footprint_per_capita': F / P, 'EG_reference_per_capita': budget[u],
                                          'LE_reference_per_capita': le / P}).rename_axis('actor').reset_index())
references = pd.concat(ref_rows)

T = cfg.TABLES
sheets = {
    'S1_regions_population': pd.DataFrame({'region': pop.index, 'region_name': pop.index.map(REGION_NAMES),
                                           'EU27': pop.index.isin(cfg.EU27), 'population_2015': pop.values}),
    'S2_DLS_basket': basket,
    'S3_DLS_prices_Comtrade': pd.read_csv(cfg.PRICES_FILE) if cfg.PRICES_FILE.exists() else pd.DataFrame(),
    'S4_generation_mix': gen,
    'S5_proxy_recipes': prox,
    'S6_footprints_per_capita': footprints,
    'S7_references_per_capita': references,
    'S8_indicators': pd.read_csv(T / 'indicators.csv'),
    'S9_SF_absolute': pd.read_csv(T / 'sf_absolute.csv'),
    'S10_country_changes': pd.read_csv(T / 'country_changes.csv'),
    'S11_sens_normative': pd.read_csv(T / 'sensitivity_normative.csv'),
    'S12_sens_Casal': pd.read_csv(T / 'sensitivity_casal.csv'),
    'S13_sens_country_weights': pd.read_csv(T / 'sensitivity_country_weights.csv'),
    'S14_sens_territorial': pd.read_csv(T / 'sensitivity_territorial_EG_LE.csv'),
    'S15_Theil': pd.read_csv(T / 'theil_decomposition.csv'),
    'S16_EU_footprint_by_origin': pd.read_csv(T / 'eu_footprint_by_origin.csv'),
    'S17_validation_DLS': pd.read_csv(T / 'validation_dls_per_capita.csv'),
    'S18_validation_literature': pd.read_csv(T / 'validation_dls_literature.csv'),
}
readme = pd.DataFrame({'sheet': list(sheets), 'content': [
    'EXIOBASE regions, EU27 membership, population on 1 January 2015 (UN WPP 2024)',
    'DLS items per person: quantity, HS code, price used and its source, EUR per person per year, EXIOBASE sector',
    'Comtrade 2015 world import unit values per HS code, converted to DLS units',
    'Electricity generation (GWh) by EU country and technology, 2015 and 2050 (Cerny et al., 2022)',
    'Proxy countries for technologies absent in 2015 (Cerny et al., 2022, Section 8.3)',
    'Consumption-based and territorial footprints and DLS threshold per person, by region and model scenario (BAU = baseline, EUREF, Stanford)',
    'Footprint, egalitarian and liberal egalitarian references per person, by scope, actor and model scenario',
    'Main indicators (Table 5 of the article) with absolute distances',
    'Sufficientarian absolute indicator: actors below the threshold',
    'Per-actor changes and shares of the BAU distance (Table 6 of the article)',
    'Normative sensitivity: tax rate x budget definition',
    'Priority-based (Casal, 2011) variant of the liberal egalitarian redistribution rule',
    'Indicators with each country counting once',
    'Egalitarian and liberal egalitarian indicators with territorial accounting',
    'Theil T decomposition of world footprint inequality: EU27 vs rest of world',
    'EU27 footprint by region of emission (inside vs outside the EU)',
    'DLS footprint per person by region (CO2, water, energy)',
    'DLS footprint compared with the literature']})
# reader-facing name: the code calls BAU/EUREF/Stanford 'states'; the article calls them 'model scenarios'
sheets = {k: v.rename(columns={'state': 'model_scenario', 'State': 'Model_scenario'}) for k, v in sheets.items()}
with pd.ExcelWriter(cfg.RESULTS / 'DJIO_SI_tables.xlsx') as xl:
    readme.to_excel(xl, sheet_name='README', index=False)
    for name, df in sheets.items():
        df.to_excel(xl, sheet_name=name[:31], index=False)
print('Saved', cfg.RESULTS / 'DJIO_SI_tables.xlsx', 'and processed input tables in', cfg.PROCESSED)
