# -*- coding: utf-8 -*-
"""
03_electricity_scenarios.py
BAU and two EU electricity decarbonisation scenarios (EU Reference 2016, Stanford WWS) in
EXIOBASE 3.7 ixi 2015, following the scenario data of Cerny et al. (2022).

Method
- Each EU27 country's electricity purchases (every column of A and Y) keep their total and are
  re-split across technologies with the country's GENERATION (GWh) mix: 2015 mix for BAU,
  2050 mix for the scenarios. Same procedure for all states -> policy vs BAU = change of mix.
- Technologies absent from a country in 2015 (output < cfg.MIN_OUTPUT_MEUR) get the input column of A and the intensities of a
  proxy country (Cerny et al., 2022, Section 8.3), domestic inputs re-assigned to the host.
- Direct CO2 that EXIOBASE books on non-combustion technologies (wind, PV, hydro...) is moved to
  the same country's fuel-burning technologies (cfg.REALLOCATE_NONCOMBUSTION_CO2).
- EU27: a country's electricity CO2 is re-split across technologies with 2015 GWh x direct
  emission factors (cfg.EF_ALLOCATION_EU); national totals unchanged.
- Proxy recipes re-localise domestic inputs only to host sectors with real output.
- Footprints are consumption-based: M = f (I - A)^-1, footprint of j = M . Y[:, j] (+ household
  direct emissions). Territorial emissions are also saved for the sensitivity analysis.
- Memory: one LU factorisation of (I - A) per state, reused for all extensions (~3 GB RAM).
Outputs: results/footprints/{consumption,territorial}/FP_{state}_{unit}.csv (native units),
         results/footprints/origin/FP_EU_by_origin_{state}_{unit}.csv (region of emission x EU country),
         results/multipliers/M_{state}_{unit}.csv  (+ energy multipliers for validation)
"""
import sys
import gc
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import numpy as np
import pandas as pd
from scipy.linalg import lu_factor, lu_solve
import config as cfg

#%% Scenario data: generation by country x technology

WIND = ['Production of electricity by wind offshore', 'Production of electricity by wind onshore']
SOLAR = ['Production of electricity by solar photovoltaic residential',
         'Production of electricity by solar photovoltaic utility']

def read_generation(sheet):
    df = pd.read_excel(cfg.SCENARIOS_FILE, sheet_name=sheet)
    gen_cols = [c for c in df.columns if str(c).startswith('gen')]
    total_2015 = df.groupby('Country.Code')['gen2015'].transform('sum')
    too_big = df[gen_cols].max(axis=1) > cfg.DATA_CHECK_MAX_RATIO * total_2015
    if too_big.any():
        print(df.loc[too_big, ['Country.Code', 'Industry.Name', 'gen2015', 'gen2050']])
        raise ValueError(f'{sheet}: implausible generation values. Use the unmodified Scenarios.xlsx of Cerny et al. (2022).')
    df = df[df['Country.Code'].isin(cfg.EU27)].copy()
    df['sector'] = df['Industry.Name'].replace({**{w: 'Production of electricity by wind' for w in WIND},
                                                **{s: 'Production of electricity by solar photovoltaic' for s in SOLAR}})
    gen = df.groupby(['Country.Code', 'sector'])[['gen2015', 'gen2050']].sum()
    gen.index.names = ['region', 'sector']
    return gen

def generation_mix(gen_col):
    return (gen_col / gen_col.groupby(level='region').transform('sum')).fillna(0)

gen_euref, gen_stanford = read_generation('euref_det'), read_generation('stanford_det')
MIX = {'baseline': generation_mix(gen_euref['gen2015']),           # 2015 identical in both sheets
       'euref': generation_mix(gen_euref['gen2050']),
       'stanford': generation_mix(gen_stanford['gen2050'])}

#%% EXIOBASE 2015 ixi (kept as numpy arrays + index to save memory)

print('Reading EXIOBASE ...')
rd = dict(sep='\t', header=[0, 1], index_col=[0, 1])
A_df = pd.read_csv(cfg.EXIOBASE_DIR / 'A.txt', **rd).sort_index().sort_index(axis=1)
idx = A_df.index
assert idx.equals(A_df.columns)
A = A_df.to_numpy(dtype=float, copy=True)
del A_df; gc.collect()
Y_df = pd.read_csv(cfg.EXIOBASE_DIR / 'Y.txt', **rd).sort_index(axis=1).reindex(idx)
Y, ycols = Y_df.to_numpy(dtype=float), Y_df.columns
pos = {lab: i for i, lab in enumerate(idx)}
n = len(idx)

def leontief_lu(A_s):
    B = -A_s
    B[np.diag_indices(n)] += 1.0                       # B = I - A
    return lu_factor(B, overwrite_a=True, check_finite=False)

lu0 = leontief_lu(A.copy())
X = lu_solve(lu0, Y.sum(axis=1), check_finite=False)   # total output, base year
del lu0; gc.collect()
(cfg.MULTIPLIERS).mkdir(parents=True, exist_ok=True)
pd.Series(X, index=idx, name='x_2015_MEUR').to_csv(cfg.MULTIPLIERS / 'x_2015.csv')   # used by 04

def read_extension(name):
    path = cfg.EXIOBASE_DIR / 'satellite' / name
    if not path.exists():
        return None
    F = pd.read_csv(path, sep='\t', header=[0, 1], index_col=0, low_memory=False)
    return F.apply(pd.to_numeric, errors='coerce')

def select_rows(F, keywords):
    mask = F.index.to_series().apply(lambda r: any(k in r for k in keywords))
    return F.loc[mask].sum(axis=0)

EXT = {'co2': cfg.CO2_KEYWORDS, 'water': cfg.WATER_KEYWORDS, 'energy': cfg.ENERGY_KEYWORDS}
EXT.update(cfg.ENERGY_PART_KEYWORDS)                     # validation only
F = read_extension('F.txt')
def reallocate_noncombustion_co2(tot):
    """Direct CO2 booked on wind, solar, hydro, nuclear... -> same country's fuel-burning
    electricity technologies, pro rata to their own CO2 (national total unchanged)."""
    moved = 0.0
    for r in idx.get_level_values(0).unique():
        sec = [(r, s) for s in sectors if s.startswith('Production of electricity')]
        non = [pos[k] for k in sec if any(t in k[1] for t in cfg.NONCOMBUSTION_TECH)]
        com = [pos[k] for k in sec if any(t in k[1] for t in cfg.COMBUSTION_TECH)]
        m, base = tot[non].sum(), tot[com].sum()
        if m > 0 and base > 0:
            tot[com] += m * tot[com] / base
            tot[non] = 0
            moved += m
    print(f'  co2: {moved / 1e9:.1f} Mt booked on non-combustion technologies moved to '
          f'combustion technologies ({moved / tot.sum():.2%} of world CO2)')
    return tot

sectors = idx.get_level_values(1).unique()
f0 = {}
for u, kw in EXT.items():
    tot = select_rows(F, kw).reindex(idx).fillna(0).to_numpy(dtype=float, copy=True)
    if u == 'co2' and cfg.REALLOCATE_NONCOMBUSTION_CO2:
        tot = reallocate_noncombustion_co2(tot)
    ok = X > 1e-9                                          # sectors with (almost) no output
    f0[u] = np.divide(tot, X, out=np.zeros(n), where=ok)   # -> intensity 0, never inf
    lost = tot[~ok].sum() / tot.sum() if tot.sum() else 0
    print(f'  {u}: {int((~ok).sum())} sectors with zero output; their direct {u} ({lost:.2e} of total) is dropped')
del F

def ef_based_co2_intensity(f, gen2015):
    """EU27: each country's electricity CO2 (EXIOBASE total) re-split across technologies with
    2015 GWh x emission factor; per M EUR with the country's average price per GWh."""
    print('  EU electricity CO2 intensity from emission factors (kg CO2 per EUR):')
    for c in cfg.EU27:
        g = gen2015.loc[c]
        techs = [t for t in g.index if (c, t) in pos]
        ef = pd.Series({t: next(v for k, v in cfg.ELECTRICITY_EF_T_PER_MWH.items() if k in t) for t in techs})
        rows = [pos[(c, t)] for t in techs]
        total_kg = (f[rows] * X[rows]).sum()
        expected_kg = (g[techs] * ef).sum() * 1e6                     # GWh x t/MWh -> kg
        steam = pos.get((c, 'Steam and hot water supply'))
        if cfg.MOVE_CHP_CO2_TO_ELECTRICITY and steam is not None and total_kg < expected_kg and X[steam] > 0:
            moved = min(expected_kg - total_kg, f[steam] * X[steam])
            f[steam] -= moved / X[steam]
            total_kg += moved
            print(f'    {c}: {moved / 1e9:.1f} Mt CO2 moved from steam and hot water supply to electricity')
        price = X[rows].sum() / g[techs].sum()                 # M EUR per GWh
        if (g[techs] * ef).sum() == 0 or total_kg == 0:
            continue
        f[rows] = total_kg * ef.values / (g[techs] * ef).sum() / price
        print(f'    {c}: ' + ', '.join(f'{t.replace("Production of electricity by ", "")[:8]} {f[pos[(c, t)]] / 1e6:.2f}'
                                      for t in techs if ef[t] > 0 and g[t] > 0))
    return f

if cfg.EF_ALLOCATION_EU:
    f0['co2'] = ef_based_co2_intensity(f0['co2'], gen_euref['gen2015'])

F_hh = read_extension('F_hh.txt')
if F_hh is None:
    F_hh = read_extension('F_Y.txt')
hh = {u: 0 for u in EXT}
if cfg.INCLUDE_HOUSEHOLD_DIRECT and F_hh is not None:
    hh = {u: select_rows(F_hh, kw).groupby(level=0).sum() for u, kw in EXT.items()}

#%% Proxies for technologies absent in 2015

proxies = pd.read_excel(cfg.PROXY_FILE, sheet_name='new') if cfg.PROXY_FILE.exists() else None

def patch_missing_recipes(A_s, f, mix, state):
    for (c, t), share in mix.items():
        if share == 0 or X[pos[(c, t)]] >= cfg.MIN_OUTPUT_MEUR:
            continue
        proxy = None
        if proxies is not None:
            p = proxies[(proxies['country missing a technology in 2015'] == c) & (proxies['technology'] == t)]
            if len(p) and X[pos[(p['Replacement country'].iloc[0], t)]] >= cfg.MIN_OUTPUT_MEUR:
                proxy = p['Replacement country'].iloc[0]
        if proxy is None:                                    # fallback: largest EU producer
            proxy = max(cfg.EU27, key=lambda r: X[pos[(r, t)]])
            print(f'  no proxy listed for {c} / {t}: using {proxy}')
        col = A_s[:, pos[(proxy, t)]].copy()
        for s in sectors:                                    # re-localise domestic inputs, only to
            if X[pos[(c, s)]] >= cfg.MIN_OUTPUT_MEUR:        # host sectors that really exist (CY has
                col[pos[(c, s)]] += col[pos[(proxy, s)]]     # no refinery: keep buying it from proxy)
                col[pos[(proxy, s)]] = 0
        A_s[:, pos[(c, t)]] = col
        for u in f:
            if u == 'co2' and cfg.EF_ALLOCATION_EU:
                continue                                     # host's EF-based intensity already set
            f[u][pos[(c, t)]] = f[u][pos[(proxy, t)]]
        print(f'  {state}: {c} / {t} uses the recipe of {proxy}')

#%% Re-split electricity purchases with the generation mix

def apply_mix(M, mix):
    """In place: each buyer keeps its total purchases of country c's electricity, re-split with
    c's generation shares (national grid mix, uniform price per kWh)."""
    for c in mix.index.get_level_values('region').unique():
        tech = mix.loc[c]
        missing = [t for t in tech.index if (c, t) not in pos]
        if missing:
            raise KeyError(f'Technologies not found in EXIOBASE for {c}: {missing}')
        rows = [pos[(c, t)] for t in tech.index]
        E = M[rows, :].sum(axis=0)
        M[rows, :] = np.outer(tech.values, E)

#%% Build the three states

out_cons, out_terr, out_M = (cfg.FOOTPRINTS / 'consumption', cfg.FOOTPRINTS / 'territorial', cfg.MULTIPLIERS)
out_origin = cfg.FOOTPRINTS / 'origin'          # EU27 footprints by region of emission
for d in (out_cons, out_terr, out_M, out_origin):
    d.mkdir(parents=True, exist_ok=True)

for state, mix in MIX.items():
    A_s, Y_s = A.copy(), Y.copy()
    f_s = {u: v.copy() for u, v in f0.items()}
    patch_missing_recipes(A_s, f_s, mix, state)
    apply_mix(A_s, mix)
    apply_mix(Y_s, mix)
    used = [pos[k] for k, v in mix.items() if v > 0]
    top = pd.Series(f_s['co2'][used], index=idx[used]).nlargest(3)
    print(f'{state}: highest direct CO2 intensities in the mix (kg/MEUR):', top.round(-3).to_dict())
    print(f'{state}: max column sum of A = {A_s.sum(axis=0).max():.4f} '
          '(a few tiny EXIOBASE sectors sit at 1.0000; the LU still solves)')
    lu = leontief_lu(A_s); del A_s; gc.collect()
    x_s = lu_solve(lu, Y_s.sum(axis=1), check_finite=False)
    for u in EXT:
        M = lu_solve(lu, f_s[u], trans=1, check_finite=False)            # M = f (I - A)^-1
        M_ser = pd.Series(M, index=idx)
        M_ser.rename(f'M_{state}_{u}').to_csv(out_M / f'M_{state}_{u}.csv')
        if u.startswith('energy'):
            continue                                                     # validation only
        cons = pd.Series(M @ Y_s, index=ycols).groupby(level=0).sum() + hh[u]
        terr = pd.Series(f_s[u] * x_s, index=idx).groupby(level=0).sum() + hh[u]
        cons.rename(f'FP_{state}_{u}').rename_axis('region').to_csv(out_cons / f'FP_{state}_{u}.csv')
        terr.rename(f'TE_{state}_{u}').rename_axis('region').to_csv(out_terr / f'FP_{state}_{u}.csv')
    # Where are the EU27 consumption footprints emitted? (region of emission x consuming country)
    eu_cols = [j for j, c in enumerate(ycols) if c[0] in cfg.EU27]
    y_eu = pd.DataFrame(Y_s[:, eu_cols], columns=ycols[eu_cols]).T.groupby(level=0).sum().T
    X_eu = lu_solve(lu, y_eu.to_numpy(), check_finite=False)           # output needed by each EU country
    for u in cfg.CURRENCIES:
        by_origin = pd.DataFrame(f_s[u][:, None] * X_eu, index=idx, columns=y_eu.columns).groupby(level=0).sum()
        if isinstance(hh[u], pd.Series):                                  # household direct: emitted at home
            for c in y_eu.columns:
                by_origin.loc[c, c] += hh[u].get(c, 0)
        by_origin.rename_axis('region_of_emission').to_csv(out_origin / f'FP_EU_by_origin_{state}_{u}.csv')
    del lu, Y_s; gc.collect()
    print(f'{state}: done')
print('Footprints and multipliers saved in', cfg.RESULTS)
