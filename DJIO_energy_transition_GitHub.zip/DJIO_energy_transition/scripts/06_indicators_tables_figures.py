# -*- coding: utf-8 -*-
"""
06_indicators_tables_figures.py
Distributive justice indicators (centred on 1), tables and radar chart.

Indicator = distance(policy) / distance(BAU): 1 = as far from the benchmark as BAU,
< 1 closer, 0 = benchmark reached, NaN = not defined (nothing to improve under BAU).
- SF-Absolute: number of actors below the DLS threshold, population share H, who left / entered
- SF-Relative: root mean squared relative shortfall (only shortfalls count)
- EG: population-weighted RMSD of per-capita footprints from the equal share (+ level / dispersion)
- LE: population-weighted RMSD from the liberal-egalitarian reference (= RMS net transfer needed)
Outputs (results/tables, results/figures):
  indicators.csv                     main results
  sensitivity_country_weights.csv    each country counts once
  sensitivity_territorial_EG_LE.csv  territorial instead of consumption accounting
  sensitivity_normative.csv          tax rate x budget grid (EG, LE)
  theil_decomposition.csv            inequality between / within EU27 and rest of world
  country_changes.csv, country_detail/..., sf_absolute.csv, fig_radar.png/.pdf
Absolute distances D_BAU and D_POL (per capita, t or m3) are reported next to every ratio.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import numpy as np
import pandas as pd
import matplotlib
import matplotlib.pyplot as plt
import config as cfg
from djio_functions import (read_series, to_scope, egalitarian_reference, liberal_egalitarian_reference,
                            indicators, country_changes, theil_decomposition, casal_rate, casal_reference,
                            rmsd, ratio)

cfg.TABLES.mkdir(parents=True, exist_ok=True)
cfg.FIGURES.mkdir(parents=True, exist_ok=True)
(cfg.TABLES / 'country_detail').mkdir(exist_ok=True)

#%% Load (convert footprints and SF thresholds to t / m3)

pop = read_series(cfg.POP_FILE)
conv = cfg.TO_BUDGET_UNIT
FP = {(s, u): read_series(cfg.FOOTPRINTS / 'consumption' / f'FP_{s}_{u}.csv') * conv[u]
      for s in cfg.STATES for u in cfg.CURRENCIES}
TE = {(s, u): read_series(cfg.FOOTPRINTS / 'territorial' / f'FP_{s}_{u}.csv') * conv[u]
      for s in cfg.STATES for u in cfg.CURRENCIES}
SF = {(s, u): read_series(cfg.REFERENCES / 'sf' / f'FP_SF_{u}_{s}.csv') * conv[u]
      for s in cfg.STATES for u in cfg.CURRENCIES}
EG = {(u, sc): read_series(cfg.REFERENCES / 'eg' / f'EG_{u}_{sc}.csv')
      for u in cfg.CURRENCIES for sc in cfg.SCOPES}
LE = {(s, u, sc): read_series(cfg.REFERENCES / 'le' / f'LE_{s}_{u}_{sc}.csv')
      for s in cfg.STATES for u in cfg.CURRENCIES for sc in cfg.SCOPES}

BUDGET = read_series(cfg.REFERENCES / 'budget_per_capita.csv').to_dict()
pc = (FP[('baseline', 'co2')] / pop).loc[cfg.EU27]
print(f'Check units - EU per-capita CO2 footprint: {pc.min():.1f} to {pc.max():.1f} t (expected ~5-20 t)')

#%% Main table, Appendix 2, Table 7, sensitivity: country weights

def run(weighting):
    rows, t7 = [], []
    for scen in cfg.SCENARIOS:
        for u in cfg.CURRENCIES:
            for sc in cfg.SCOPES:
                P = to_scope(pop, sc, cfg.EU27)
                g = lambda d, k: to_scope(d[k], sc, cfg.EU27).loc[P.index]
                F_b, F_p = g(FP, ('baseline', u)), g(FP, (scen, u))
                S_b, S_p = g(SF, ('baseline', u)), g(SF, (scen, u))
                R_eg = EG[(u, sc)].loc[P.index]
                R_le_b = LE[('baseline', u, sc)].loc[P.index]
                R_le_p = LE[(scen if cfg.LE_REFERENCE_STATE == 'own' else 'baseline', u, sc)].loc[P.index]
                key = {'Scenario': scen.upper(), 'Currency': u, 'Scope': sc}
                rows.append({**key, **indicators(F_b, F_p, P, R_eg, R_le_b, R_le_p, S_b, S_p, weighting)})
                for shape, (Rb, Rp) in {'EG': (R_eg, R_eg), 'LE': (R_le_b, R_le_p)}.items():
                    cc = country_changes(F_b, F_p, Rb, Rp, P, weighting)
                    if weighting == cfg.WEIGHTING:
                        cc.to_csv(cfg.TABLES / 'country_detail' / f'{scen}_{shape}_{u}_{sc}.csv')
                    top3 = cc['share_of_D2_BAU'].sort_values(ascending=False).head(3)
                    t7.append({**key, 'Shape': shape, 'Improving': int((cc.abs_change < 0).sum()),
                               'Worsening': int((cc.abs_change > 0).sum()),
                               'Pct_improving': 100 * (cc.abs_change < 0).mean(),
                               'Top3_share_of_BAU_distance': '; '.join(f'{k} {v:.0%}' for k, v in top3.items())})
    return pd.DataFrame(rows), pd.DataFrame(t7)

table6, table7 = run(cfg.WEIGHTING)
sf_cols = ['Scenario', 'Currency', 'Scope', 'SF_abs_N_BAU', 'SF_abs_N_POL', 'SF_abs_H_BAU', 'SF_abs_H_POL', 'SF_left', 'SF_entered']
table6[sf_cols].to_csv(cfg.TABLES / 'sf_absolute.csv', index=False)
table6.drop(columns=['SF_left', 'SF_entered']).to_csv(cfg.TABLES / 'indicators.csv', index=False)
table7.to_csv(cfg.TABLES / 'country_changes.csv', index=False)
show = ['Scenario', 'Currency', 'Scope', 'SF_abs_dN', 'SF_rel', 'EG', 'EG_level', 'EG_dispersion', 'LE']
print(table6[show].round(3).to_string(index=False))

sens_w, _ = run(cfg.SENSITIVITY_WEIGHTING)
sens_w.drop(columns=['SF_left', 'SF_entered']).to_csv(cfg.TABLES / 'sensitivity_country_weights.csv', index=False)

#%% Sensitivity: territorial accounting (EG and LE only; the DLS threshold is consumption-based)

if cfg.TERRITORIAL_SENSITIVITY:
    rows = []
    for scen in cfg.SCENARIOS:
        for u in cfg.CURRENCIES:
            for sc in cfg.SCOPES:
                P = to_scope(pop, sc, cfg.EU27)
                F_b = to_scope(TE[('baseline', u)], sc, cfg.EU27).loc[P.index]
                F_p = to_scope(TE[(scen, u)], sc, cfg.EU27).loc[P.index]
                le = lambda F: liberal_egalitarian_reference(F, P, BUDGET[u],
                                                             cfg.LE_TAX_RATE, cfg.LE_SURPLUS_RULE)
                R_le_b = le(F_b)
                R_le_p = le(F_p) if cfg.LE_REFERENCE_STATE == 'own' else R_le_b
                rows.append({'Scenario': scen.upper(), 'Currency': u, 'Scope': sc,
                             **indicators(F_b, F_p, P, EG[(u, sc)].loc[P.index], R_le_b, R_le_p,
                                          weighting=cfg.WEIGHTING)})
    pd.DataFrame(rows).to_csv(cfg.TABLES / 'sensitivity_territorial_EG_LE.csv', index=False)

#%% Normative sensitivity: LE tax rate x budget definition (EG and LE)

world_avg = {u: FP[('baseline', u)].sum() / pop.sum() for u in cfg.CURRENCIES}      # t or m3 per person
budget = {'planetary_boundary': cfg.PB_PER_CAPITA, 'current_world_average': world_avg}
rows = []
for b_name in cfg.SENS_BUDGETS:
    for tax in cfg.SENS_TAX_RATES:
        for scen in cfg.SCENARIOS:
            for u in cfg.CURRENCIES:
                for sc in cfg.SCOPES:
                    P = to_scope(pop, sc, cfg.EU27)
                    F_b = to_scope(FP[('baseline', u)], sc, cfg.EU27).loc[P.index]
                    F_p = to_scope(FP[(scen, u)], sc, cfg.EU27).loc[P.index]
                    b = budget[b_name][u]
                    le = lambda F: liberal_egalitarian_reference(F, P, b, tax, cfg.LE_SURPLUS_RULE)
                    R_le_b = le(F_b)
                    R_le_p = le(F_p) if cfg.LE_REFERENCE_STATE == 'own' else R_le_b
                    r = indicators(F_b, F_p, P, egalitarian_reference(P, b), R_le_b, R_le_p, weighting=cfg.WEIGHTING)
                    rows.append({'Budget': b_name, 'Tax_rate': tax, 'Scenario': scen.upper(), 'Currency': u,
                                 'Scope': sc, 'Budget_per_capita': b, 'EG': r['EG'], 'LE': r['LE']})
sens = pd.DataFrame(rows)
sens.to_csv(cfg.TABLES / 'sensitivity_normative.csv', index=False)
ranges = sens.groupby(['Scenario', 'Currency', 'Scope'])[['EG', 'LE']].agg(['min', 'max'])

#%% Inequality decomposition: between EU27 and rest of world vs within each group (Theil T)

groups = {r: ('EU27' if r in cfg.EU27 else 'RoW') for r in pop.index}
rows = []
for state in cfg.STATES:
    for u in cfg.CURRENCIES:
        rows.append({'State': state.upper(), 'Currency': u,
                     **theil_decomposition(FP[(state, u)], pop, groups)})
theil = pd.DataFrame(rows)
theil.to_csv(cfg.TABLES / 'theil_decomposition.csv', index=False)
print(theil.round(4).to_string(index=False))

#%% Sensitivity: Casal-style LE (Global Share: priority distribution, no cut-off)
# Rate = Casal's 'minimal rate to reach the budget' (share of the above-threshold footprint that
# would have to go for the scope to fit its budget), fixed at its BAU value; and 50% for comparison.

rows = []
for scen in cfg.SCENARIOS:
    for u in cfg.CURRENCIES:
        for sc in cfg.SCOPES:
            P = to_scope(pop, sc, cfg.EU27)
            F_b = to_scope(FP[('baseline', u)], sc, cfg.EU27).loc[P.index]
            F_p = to_scope(FP[(scen, u)], sc, cfg.EU27).loc[P.index]
            t_star = casal_rate(F_b, P, BUDGET[u])
            row = {'Scenario': scen.upper(), 'Currency': u, 'Scope': sc,
                   'casal_rate_BAU': t_star, 'casal_rate_POL': casal_rate(F_p, P, BUDGET[u]),
                   'LE_main': table6.set_index(['Scenario', 'Currency', 'Scope']).loc[(scen.upper(), u, sc), 'LE']}
            for name, rate in [('rate_star', t_star), ('rate_50', 0.5)]:
                R_b = casal_reference(F_b, P, BUDGET[u], rate, cfg.CASAL_ETA)
                R_p = casal_reference(F_p, P, BUDGET[u], rate, cfg.CASAL_ETA)
                d_b, d_p = rmsd(F_b, R_b, P, cfg.WEIGHTING), rmsd(F_p, R_p, P, cfg.WEIGHTING)
                row.update({f'LE_casal_{name}': ratio(d_p, d_b), f'D_BAU_{name}': d_b, f'D_POL_{name}': d_p})
            rows.append(row)
casal = pd.DataFrame(rows)
casal.to_csv(cfg.TABLES / 'sensitivity_casal.csv', index=False)
print(casal[['Scenario', 'Currency', 'Scope', 'casal_rate_BAU', 'LE_main', 'LE_casal_rate_star', 'LE_casal_rate_50']].round(3).to_string(index=False))

#%% Where the EU27 footprint is emitted: inside vs outside the EU (Bruckner et al., 2023)

origin_dir = cfg.FOOTPRINTS / 'origin'
if origin_dir.exists():
    rows = []
    for u in cfg.CURRENCIES:
        tot = {}
        for state in cfg.STATES:
            o = pd.read_csv(origin_dir / f'FP_EU_by_origin_{state}_{u}.csv', index_col=0) * conv[u]
            o.index = o.index.astype(str)
            inside, outside = o.loc[o.index.isin(cfg.EU27)].values.sum(), o.loc[~o.index.isin(cfg.EU27)].values.sum()
            tot[state] = (inside, outside)
        for state in cfg.STATES:
            i, o_ = tot[state]
            i0, o0 = tot['baseline']
            rows.append({'State': state.upper(), 'Currency': u, 'EU27_footprint': i + o_,
                         'emitted_inside_EU': i, 'emitted_outside_EU': o_, 'share_outside': o_ / (i + o_),
                         'change_inside_vs_BAU': i - i0, 'change_outside_vs_BAU': o_ - o0,
                         'share_of_change_outside': (o_ - o0) / ((i + o_) - (i0 + o0)) if state != 'baseline' else np.nan})
    origin = pd.DataFrame(rows)
    origin.to_csv(cfg.TABLES / 'eu_footprint_by_origin.csv', index=False)
    print(origin.round(3).to_string(index=False))

#%% Radar chart: SF-Relative, EG, LE; BAU = unit circle

axes = [(sc, u, k) for sc in cfg.SCOPES for u in cfg.CURRENCIES for k in ['SF_rel', 'EG', 'LE']]
labels = [f"{k.replace('_rel', '-Rel')}\n{sc} {'CO$_2$' if u == 'co2' else 'water'}" for sc, u, k in axes]
ang = np.linspace(0, 2 * np.pi, len(axes), endpoint=False)
style = {'EUREF': ('#E69F00', 'o'), 'STANFORD': ('#B2182B', 's')}

fig, ax = plt.subplots(figsize=(9, 9), subplot_kw=dict(polar=True))
undefined, vmax = set(), 1.2
for scen, (col, mk) in style.items():
    t = table6[table6.Scenario == scen].set_index(['Scope', 'Currency'])
    v = np.array([t.loc[(sc, u), k] for sc, u, k in axes], dtype=float)
    undefined |= {i for i in np.where(np.isnan(v))[0]}
    vmax = max(vmax, 1.1 * np.nanmax(v)) if np.isfinite(np.nanmax(v)) else vmax
    vp = np.where(np.isnan(v), 1.0, v)
    ax.plot(np.r_[ang, ang[:1]], np.r_[vp, vp[:1]], color=col, lw=2, label=scen.title())
    ax.scatter(ang[~np.isnan(v)], vp[~np.isnan(v)], color=col, marker=mk, s=55, zorder=3)
    ax.scatter(ang[np.isnan(v)], vp[np.isnan(v)], facecolors='none', edgecolors=col, marker=mk, s=55, zorder=3)
    for i, (sc, u, k) in enumerate(axes):                 # whiskers: normative sensitivity range
        if k in ('EG', 'LE'):
            lo, hi = ranges.loc[(scen, u, sc), (k, 'min')], ranges.loc[(scen, u, sc), (k, 'max')]
            ax.plot([ang[i] + (0.03 if scen == 'STANFORD' else -0.03)] * 2, [lo, hi], color=col, lw=1.2, alpha=0.7)
            vmax = max(vmax, 1.1 * hi)
ax.plot(np.r_[ang, ang[:1]], np.ones(len(ang) + 1), ls='--', color='grey', lw=1.2, label='BAU (= 1)')
ax.set_xticks(ang)
ax.set_xticklabels([l + (' †' if i in undefined else '') for i, l in enumerate(labels)], fontsize=8)
ax.set_ylim(0, vmax)
ax.set_rlabel_position(15)
ax.legend(loc='upper right', bbox_to_anchor=(1.25, 1.1), frameon=False)
ax.set_title('Distance to justice benchmarks relative to BAU\n(< 1 closer, 0 benchmark reached, † not defined;'
             ' lines: range over tax rates and budgets)', pad=24)
fig.tight_layout()
fig.savefig(cfg.FIGURES / 'fig_radar.png', dpi=300)
fig.savefig(cfg.FIGURES / 'fig_radar.pdf')
print('Tables and figures saved in', cfg.RESULTS)
