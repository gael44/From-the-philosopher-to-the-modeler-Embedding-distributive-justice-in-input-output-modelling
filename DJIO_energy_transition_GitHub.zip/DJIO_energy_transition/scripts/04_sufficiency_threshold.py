# -*- coding: utf-8 -*-
"""
04_sufficiency_threshold.py
Sufficientarian benchmark: the footprint of a Decent Living Standards (DLS) basket for every
person of each region, computed with the technology of each state (baseline, euref, stanford).

Steps
1. DLS monetary requirements (EUR per person per year) = quantity x price, with 2015 Comtrade
   prices from script 02 (sheet prices kept for tap water and wastewater); items mapping to the
   same EXIOBASE sector are SUMMED (sector final demand = total spending on that sector).
2. x population / 1e6 -> M EUR per region; origin of each product = the region's own import
   structure for that product (world origin mix if the region buys none of it).
   Demand above an origin's 2015 output is bought with the world origin mix (capacity check).
3. Footprint = M_state . Y_DLS[:, region]  (multipliers of the SAME state).
4. CO2: + direct combustion of the DLS natural gas (cooking, heating), consistent with the
   household direct emissions included in the observed footprints.
Mobility items (passenger-km) have no price and are excluded: the threshold is a lower bound.
Output: results/references/sf/FP_SF_{unit}_{state}.csv (native units: kg, Mm3)
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import numpy as np
import pandas as pd
import config as cfg
from djio_functions import load_dls_basket

#%% 1. DLS requirements per person

dls = load_dls_basket(cfg)

gas_m3_pc = float(dls.loc[dls['ReferenceProduct'] == cfg.DLS_GAS_ITEM, 'Quantity'].sum())
dls_pc = dls[['Exiobase sector', 'Values']].dropna().groupby('Exiobase sector')['Values'].sum()
dls_pc = dls_pc * cfg.DLS_PRICE_FACTOR                                     # EUR / person / year
print(f'DLS basket: {dls_pc.sum():.1f} EUR per person per year in {len(dls_pc)} sectors')

pop = pd.read_csv(cfg.POP_FILE, index_col=0).iloc[:, 0]

#%% 2. DLS final demand by origin and consuming region (M EUR)

Y = pd.read_csv(cfg.EXIOBASE_DIR / 'Y.txt', sep='\t', header=[0, 1], index_col=[0, 1]).sort_index()
Y = Y.T.groupby(level=0).sum().T                                           # consuming regions
missing = set(dls_pc.index) - set(Y.index.get_level_values(1))
if missing:
    raise KeyError(f'DLS sectors not found in EXIOBASE: {missing}')

share = Y / Y.groupby(level=1).transform('sum').replace(0, np.nan)        # origin shares, by label
world = Y.sum(axis=1)
world_share = (world / world.groupby(level=1).transform('sum')).fillna(0)
share = share.apply(lambda col: col.fillna(world_share)).fillna(0)

dls_by_region = pd.DataFrame(np.outer(dls_pc.values, pop.reindex(Y.columns).values),
                             index=dls_pc.index, columns=Y.columns) / 1e6  # M EUR
Y_DLS = share * dls_by_region.reindex(Y.index.get_level_values(1)).fillna(0).values

# Capacity check: a region cannot buy more of a product from an origin than that origin produced
# in 2015 (e.g. ID water supply: 0.05 M EUR of output vs 37 M EUR of DLS demand, with a spurious
# intensity of 2.5e11 kg CO2/MEUR). The excess is bought on the world market (world origin mix).
X = pd.read_csv(cfg.MULTIPLIERS / 'x_2015.csv', index_col=[0, 1]).iloc[:, 0].reindex(Y_DLS.index).fillna(0)
excess = Y_DLS.sub(X, axis=0).clip(lower=0)
if cfg.DLS_CAPACITY_FACTOR is None:
    excess = excess * 0
else:
    excess = excess.where(Y_DLS.gt(cfg.DLS_CAPACITY_FACTOR * X, axis=0), 0)
print(f'DLS demand above origin capacity: {excess.values.sum() / Y_DLS.values.sum():.2%} -> world mix')
Y_DLS = Y_DLS - excess
excess_by_product = excess.groupby(level=1).sum()
Y_DLS = Y_DLS + excess_by_product.reindex(Y_DLS.index.get_level_values(1)).values * world_share.values[:, None]

#%% 3-4. Footprint of the DLS basket for each state

out = cfg.REFERENCES / 'sf'
out.mkdir(parents=True, exist_ok=True)
Y_DLS.to_csv(out / 'Y_DLS.csv')                              # reused by 07_validation.py
gas_direct_kg = pop * gas_m3_pc * cfg.GAS_EF_KG_PER_M3
print(f'DLS gas combustion: {gas_m3_pc:.1f} m3 -> {gas_m3_pc * cfg.GAS_EF_KG_PER_M3 / 1000:.2f} t CO2 per person')

for state in cfg.STATES:
    for u in cfg.CURRENCIES:
        M = pd.read_csv(cfg.MULTIPLIERS / f'M_{state}_{u}.csv', index_col=[0, 1]).iloc[:, 0]
        fp = pd.Series(M.values @ Y_DLS.loc[M.index].values, index=Y_DLS.columns)
        if u == 'co2':
            fp = fp + gas_direct_kg.reindex(fp.index)
        fp.rename(f'FP_SF_{u}_{state}').rename_axis('region').to_csv(out / f'FP_SF_{u}_{state}.csv')
print('Saved SF references in', out)
