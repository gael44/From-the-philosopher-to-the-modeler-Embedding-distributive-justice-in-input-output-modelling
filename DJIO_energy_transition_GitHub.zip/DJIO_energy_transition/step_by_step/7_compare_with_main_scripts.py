# -*- coding: utf-8 -*-
"""
7_compare_with_main_scripts.py

Checks that the step-by-step scripts give the same numbers as the main scripts
(scripts/ -> results/ ; step_by_step/ -> results_step_by_step/).
Run the main pipeline (run_all.py) and the step-by-step scripts 1-6 first.
"""

import pandas as pd
import numpy as np
import os

path = os.path.dirname(os.path.abspath(__file__))
project = os.path.dirname(path)
main = os.path.join(project, 'results')
step = os.path.join(project, 'results_step_by_step')

files = ['footprints/consumption/FP_stanford_co2.csv', 'footprints/consumption/FP_euref_water.csv',
         'footprints/territorial/FP_baseline_co2.csv', 'footprints/origin/FP_EU_by_origin_stanford_co2.csv',
         'references/sf/FP_SF_co2_stanford.csv', 'references/sf/FP_SF_water_baseline.csv',
         'references/le/LE_stanford_co2_EU.csv', 'references/eg/EG_water_EUROW.csv',
         'tables/indicators.csv', 'tables/sf_absolute.csv', 'tables/country_changes.csv',
         'tables/sensitivity_country_weights.csv', 'tables/sensitivity_territorial_EG_LE.csv',
         'tables/sensitivity_normative.csv', 'tables/sensitivity_casal.csv',
         'tables/theil_decomposition.csv', 'tables/eu_footprint_by_origin.csv',
         'tables/validation_dls_per_capita.csv']

worst = 0
for f in files:
    a = pd.read_csv(os.path.join(main, f))
    b = pd.read_csv(os.path.join(step, f))
    b = b[a.columns]                                        # same column order
    num = a.select_dtypes('number').columns
    diff = (a[num] - b[num]).abs() / a[num].abs().clip(lower=1e-9)
    rel = float(np.nanmax(diff.values)) if len(num) else 0.0
    text_same = a.drop(columns=num).equals(b.drop(columns=num))
    worst = max(worst, rel)
    print(f'{f:55s} largest relative difference {rel:.1e}   text columns identical: {text_same}')
print(f'\nLargest relative difference overall: {worst:.1e}')
