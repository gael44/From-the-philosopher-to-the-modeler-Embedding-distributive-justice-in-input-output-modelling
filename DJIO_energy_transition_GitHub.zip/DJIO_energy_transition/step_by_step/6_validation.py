# -*- coding: utf-8 -*-
"""
6_validation.py

Step-by-step version of scripts/07_validation.py. Checks that the numbers are consistent
before they are interpreted:
    1. world consumption-based total = world territorial total (every model scenario)
    2. the LE institution keeps each scope's total unchanged
    3. footprints per person in BAU (EU27, world)
    4. DLS footprint per person (CO2, water, energy) compared with the literature
       (Millward-Hopkins et al. 2020: 12.3 GJ without mobility; Kikstra et al. 2021: 9.9 GJ)

Output: results_step_by_step/tables/validation_dls_per_capita.csv and printed checks
"""

import pandas as pd
import numpy as np
import os

#%% Settings

path = os.path.dirname(os.path.abspath(__file__))
project = os.path.dirname(path)
file_pop = os.path.join(project, 'data', 'processed', 'pop_2015_exiobase.csv')
file_dls = os.path.join(project, 'data', 'raw', 'dls', 'DLS_requirements_Exiobase.xlsx')
results = os.path.join(project, 'results_step_by_step')

EU27 = ["AT", "BE", "BG", "CY", "CZ", "DE", "DK", "EE", "ES", "FI", "FR", "GR", "HR", "HU",
        "IE", "IT", "LT", "LU", "LV", "MT", "NL", "PL", "PT", "RO", "SE", "SI", "SK"]
states = ['baseline', 'euref', 'stanford']
units = ['co2', 'water']
to_budget_unit = {'co2': 1e-3, 'water': 1e6}
gas_kg_co2_per_m3 = 2.0
gas_GJ_per_m3 = 0.036

pop = pd.read_csv(file_pop, index_col=0).iloc[:, 0]


def read(folder, file):
    return pd.read_csv(os.path.join(results, folder, file), index_col=0).iloc[:, 0]


#%% 1. Global balance

print('1. World total: consumption-based vs territorial')
for state in states:
    for unit in units:
        c = read('footprints/consumption', f'FP_{state}_{unit}.csv').sum()
        t = read('footprints/territorial', f'FP_{state}_{unit}.csv').sum()
        print(f'   {state:9s} {unit:6s} relative difference {abs(c / t - 1):.1e}')


#%% 2. LE conservation

print('2. LE references conserve each scope total')
worst = 0
for scope in ['EU', 'EUROW']:
    for unit in units:
        for state in states:
            F = read('footprints/consumption', f'FP_{state}_{unit}.csv') * to_budget_unit[unit]
            F_total = F.loc[EU27].sum() if scope == 'EU' else F.sum()
            R = read('references/le', f'LE_{state}_{unit}_{scope}.csv')
            worst = max(worst, abs(R.sum() / F_total - 1))
print(f'   largest relative deviation: {worst:.1e}')


#%% 3. BAU footprints per person

print('3. BAU footprints per person')
for unit in units:
    F = read('footprints/consumption', f'FP_baseline_{unit}.csv') * to_budget_unit[unit]
    per_person = F / pop
    print(f'   {unit}: EU27 {F.loc[EU27].sum() / pop.loc[EU27].sum():.2f}, world {F.sum() / pop.sum():.2f},'
          f' EU range {per_person.loc[EU27].min():.1f} ({per_person.loc[EU27].idxmin()})'
          f' - {per_person.loc[EU27].max():.1f} ({per_person.loc[EU27].idxmax()})')


#%% 4. DLS footprint per person

Y_DLS = pd.read_csv(os.path.join(results, 'references', 'sf', 'Y_DLS.csv'), index_col=[0, 1])
dls = pd.read_excel(file_dls, sheet_name='DLS-Exiobase', header=1)
gas_m3 = dls.loc[dls['ReferenceProduct'] == 'natural gas, high pressure', 'Quantity'].sum()

per_person = {}
for unit in ['co2', 'water', 'energy', 'energy_nene', 'energy_loss']:
    M = pd.read_csv(os.path.join(results, 'multipliers', f'M_baseline_{unit}.csv'), index_col=[0, 1]).iloc[:, 0]
    per_person[unit] = pd.Series(M.values @ Y_DLS.loc[M.index].values, index=Y_DLS.columns) / pop.reindex(Y_DLS.columns)

dls_pc = pd.DataFrame({
    'CO2_t_pc': per_person['co2'] * 1e-3 + gas_m3 * gas_kg_co2_per_m3 / 1000,
    'water_m3_pc': per_person['water'] * 1e6,
    'energy_GJ_pc': per_person['energy'] * 1000 + gas_m3 * gas_GJ_per_m3,       # TJ -> GJ
    'energy_excl_losses_nonenergy_GJ_pc': (per_person['energy'] - per_person['energy_nene']
                                           - per_person['energy_loss']) * 1000 + gas_m3 * gas_GJ_per_m3})
dls_pc.round(3).to_csv(os.path.join(results, 'tables', 'validation_dls_per_capita.csv'))

w = pop.reindex(dls_pc.index) / pop.reindex(dls_pc.index).sum()
print('4. DLS footprint per person (world mean, range)')
for col in dls_pc:
    print(f'   {col:36s} {(w * dls_pc[col]).sum():7.2f}   {dls_pc[col].min():.2f} - {dls_pc[col].max():.2f}')
