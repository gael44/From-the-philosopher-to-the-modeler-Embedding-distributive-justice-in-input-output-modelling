# -*- coding: utf-8 -*-
"""
3_sufficiency_threshold.py

Step-by-step version of scripts/04_sufficiency_threshold.py, written with pandas for readability.
Sufficientarian benchmark: the footprint of a Decent Living Standards (DLS) basket for every
person of each region, computed with the technology of each model scenario
(baseline, euref, stanford).

Steps
    1. DLS basket in EUR per person (quantity x 2015 Comtrade price; tap water and wastewater
       keep a utility tariff), summed by EXIOBASE sector
    2. x population -> DLS final demand of each region (M EUR)
    3. where the goods come from: the region's own import structure (world mix if it buys none);
       demand above what a supplier produced in 2015 is bought with the world mix
    4. footprint = multipliers of the model scenario x DLS final demand + direct gas combustion

Outputs: results_step_by_step/references/sf/FP_SF_{unit}_{state}.csv (kg CO2, Mm3 water) and Y_DLS.csv
"""

import pandas as pd
import numpy as np
import os

#%% Settings

path = os.path.dirname(os.path.abspath(__file__))
project = os.path.dirname(path)
path_exio = os.path.join(project, 'data', 'raw', 'exiobase', 'IOT_2015_ixi')
file_dls = os.path.join(project, 'data', 'raw', 'dls', 'DLS_requirements_Exiobase.xlsx')
file_pop = os.path.join(project, 'data', 'processed', 'pop_2015_exiobase.csv')
results = os.path.join(project, 'results_step_by_step')
file_prices = os.path.join(results, 'processed', 'DLS_prices_2015.csv')
out = os.path.join(results, 'references', 'sf')
os.makedirs(out, exist_ok=True)

states = ['baseline', 'euref', 'stanford']
units = ['co2', 'water']

gas_item = 'natural gas, high pressure'
gas_kg_co2_per_m3 = 2.0          # IPCC 2006: 56.1 t CO2/TJ x ~36 MJ/m3

# items whose sheet price is kept, because trade data do not price utility services
keep_sheet_price = ['tap water', 'wastewater, from residence']
# HS code corrected after checking the download (010511 = chicks <= 185 g)
hs_fix = {'chicken for slaughtering, live weight': 10594}


#%% 1. DLS basket in EUR per person per year

dls = pd.read_excel(file_dls, sheet_name='DLS-Exiobase', header=1)
dls = dls.loc[:, ~dls.columns.astype(str).str.contains('^Unnamed')]

# HS code used to look up the price
dls['HS_used'] = dls['ReferenceProduct'].map(hs_fix).fillna(dls['HS'])

# new price from Comtrade 2015, except for the kept items (or if the code is not in the download)
prices = pd.read_csv(file_prices, index_col=0)['EUR_per_DLS_unit']
new_price = dls['HS_used'].map(prices)
keep = dls['ReferenceProduct'].isin(keep_sheet_price) | new_price.isna()
dls['Price'] = new_price.where(~keep, dls['Price'])

# value per person = quantity x price (items without HS code, e.g. mobility, keep their value: 0)
dls['Values'] = (dls['Quantity'] * dls['Price']).where(dls['HS'].notna(), dls['Values'])

gas_m3_per_person = dls.loc[dls['ReferenceProduct'] == gas_item, 'Quantity'].sum()

# Items that fall in the same EXIOBASE sector are summed
dls_per_person = dls[['Exiobase sector', 'Values']].dropna().groupby('Exiobase sector')['Values'].sum()
print(f'DLS basket: {dls_per_person.sum():.1f} EUR per person per year in {len(dls_per_person)} sectors')

pop = pd.read_csv(file_pop, index_col=0).iloc[:, 0]


#%% 2. DLS final demand of each region (M EUR)

Y = pd.read_csv(os.path.join(path_exio, 'Y.txt'), sep='\t', header=[0, 1], index_col=[0, 1]).sort_index()
Y = Y.T.groupby(level=0).sum().T              # final demand per consuming region (7 columns summed)

dls_by_region = pd.DataFrame(np.outer(dls_per_person.values, pop.reindex(Y.columns).values),
                             index=dls_per_person.index, columns=Y.columns) / 1e6


#%% 3. Where the goods come from

# share of each origin in the region's final demand for that product (by product label)
share = Y / Y.groupby(level=1).transform('sum').replace(0, np.nan)

# world origin mix, for regions that buy none of a product
world = Y.sum(axis=1)
world_share = (world / world.groupby(level=1).transform('sum')).fillna(0)
share = share.apply(lambda col: col.fillna(world_share)).fillna(0)

# DLS demand by origin (rows) and consuming region (columns)
Y_DLS = share * dls_by_region.reindex(Y.index.get_level_values(1)).fillna(0).values

# Capacity check: a region cannot buy more from a supplier than it produced in 2015;
# the excess is bought with the world origin mix
X = pd.read_csv(os.path.join(results, 'multipliers', 'x_2015.csv'), index_col=[0, 1]).iloc[:, 0]
X = X.reindex(Y_DLS.index).fillna(0)
excess = Y_DLS.sub(X, axis=0).clip(lower=0)
excess = excess.where(Y_DLS.gt(X, axis=0), 0)
print(f'DLS demand above supplier capacity: {excess.values.sum() / Y_DLS.values.sum():.2%} -> world mix')

Y_DLS = Y_DLS - excess
excess_by_product = excess.groupby(level=1).sum()
Y_DLS = Y_DLS + excess_by_product.reindex(Y_DLS.index.get_level_values(1)).values * world_share.values[:, None]
Y_DLS.to_csv(os.path.join(out, 'Y_DLS.csv'))


#%% 4. Footprint of the DLS basket for each state

gas_direct_kg = pop * gas_m3_per_person * gas_kg_co2_per_m3
print(f'DLS gas combustion: {gas_m3_per_person * gas_kg_co2_per_m3 / 1000:.2f} t CO2 per person')

for state in states:
    for unit in units:
        M = pd.read_csv(os.path.join(results, 'multipliers', f'M_{state}_{unit}.csv'), index_col=[0, 1]).iloc[:, 0]
        footprint = pd.Series(M.values @ Y_DLS.loc[M.index].values, index=Y_DLS.columns)
        if unit == 'co2':
            footprint = footprint + gas_direct_kg.reindex(footprint.index)
        footprint.rename(f'FP_SF_{unit}_{state}').rename_axis('region').to_csv(
            os.path.join(out, f'FP_SF_{unit}_{state}.csv'))

print('Saved SF references in', out)
