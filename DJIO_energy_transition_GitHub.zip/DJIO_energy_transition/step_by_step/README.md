# Step-by-step version of the model

The scripts in this folder implement the same model as `scripts/`, written step by step with
pandas: one script per step, `#%%` cells, plain loops, and a comment on each block. They are meant
for reading and checking the method. The scripts in `scripts/` are the reference implementation
behind the article; they are shorter and faster, and read every parameter from `config.py`.

Both versions give the same results: `7_compare_with_main_scripts.py` reports a largest relative
difference of about 2e-12 on every table (rounding only).

| Step-by-step script | Main script |
|---|---|
| 1_electricity_scenarios.py | 03_electricity_scenarios.py |
| 2_dls_prices.py | 02_dls_prices.py |
| 3_sufficiency_threshold.py | 04_sufficiency_threshold.py |
| 4_justice_references.py | 05_justice_references.py |
| 5_indicators_tables_figures.py | 06_indicators_tables_figures.py |
| 6_validation.py | 07_validation.py |
| 7_compare_with_main_scripts.py | compares `results_step_by_step/` with `results/` |

Each script starts with a header saying what it does and what it produces.

## How to run

Run the scripts in order: 1, 2, 3, 4, 5, 6, then 7.

- The scripts use the same input data as the main scripts (`../data/`).
- Results are written to `../results_step_by_step/`.
- Script 1 takes about 10 minutes and needs about 4 GB of RAM. It computes the Leontief inverse
  explicitly with `np.linalg.inv`; the main scripts use an LU factorisation (`lu_factor`), which
  gives the same numbers faster.

## Vocabulary

In the code, a *state* is one of the three model runs: `baseline` (BAU, 2015 electricity mix),
`euref` and `stanford` (2050 mixes). The article calls these *model scenarios*.
