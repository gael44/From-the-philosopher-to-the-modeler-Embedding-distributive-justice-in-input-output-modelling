# -*- coding: utf-8 -*-
"""
4_justice_references.py

Step-by-step version of scripts/05_justice_references.py, written with pandas for readability.
Builds the egalitarian (EG) and liberal egalitarian (LE) reference footprints for each scope
(EU, EUROW), unit (co2, water) and model scenario.

    Budget per person: the smaller of the planetary-boundary share and the 2015 world average
        (CO2: 1.61 t, planetary boundary; blue water: 159 m3, world average)
    EG: every person gets the same budget  ->  reference = population x budget
    LE: a tax-and-transfer institution inside the scope (inspired by Casal, 2011):
        threshold = budget x population, 50% tax on the footprint above it, transfers to the
        actors below it, the rest of the revenue paid back as an equal dividend per person.
        The LE reference is computed from the footprints of each model scenario.

Outputs: results_step_by_step/references/eg, le and budget_per_capita.csv (t CO2, m3 water)
"""

import pandas as pd
import numpy as np
import os

#%% Settings

path = os.path.dirname(os.path.abspath(__file__))
project = os.path.dirname(path)
file_pop = os.path.join(project, 'data', 'processed', 'pop_2015_exiobase.csv')
results = os.path.join(project, 'results_step_by_step')
os.makedirs(os.path.join(results, 'references', 'eg'), exist_ok=True)
os.makedirs(os.path.join(results, 'references', 'le'), exist_ok=True)

EU27 = ["AT", "BE", "BG", "CY", "CZ", "DE", "DK", "EE", "ES", "FI", "FR", "GR", "HR", "HU",
        "IE", "IT", "LT", "LU", "LV", "MT", "NL", "PL", "PT", "RO", "SE", "SI", "SK"]
states = ['baseline', 'euref', 'stanford']
units = ['co2', 'water']
scopes = ['EU', 'EUROW']

planetary_boundary = {'co2': 1.61, 'water': 574.0}    # per person per year (O'Neill et al. 2018)
to_budget_unit = {'co2': 1e-3, 'water': 1e6}         # EXIOBASE kg -> t, Mm3 -> m3
tax_rate = 0.5


#%% Load population and footprints

pop = pd.read_csv(file_pop, index_col=0).iloc[:, 0]


def read_footprint(state, unit):
    """Consumption-based footprint of every region, in t CO2 or m3 water."""
    fp = pd.read_csv(os.path.join(results, 'footprints', 'consumption', f'FP_{state}_{unit}.csv'),
                     index_col=0).iloc[:, 0]
    return fp * to_budget_unit[unit]


def to_scope(s, scope):
    """EU: the 27 member states. EUROW: EU27 summed into one actor + the 22 other regions."""
    if scope == 'EU':
        return s.loc[EU27]
    eu_total = pd.Series({'EU27': s.loc[EU27].sum()})
    return pd.concat([eu_total, s.drop(index=EU27)])


#%% Budget per person: smaller of the planetary boundary share and today's world average

budget = {}
for unit in units:
    world_average = read_footprint('baseline', unit).sum() / pop.sum()
    budget[unit] = min(planetary_boundary[unit], world_average)
    print(f'{unit}: planetary boundary {planetary_boundary[unit]}, world average {world_average:.2f}'
          f' -> budget {budget[unit]:.2f} per person')
pd.Series(budget, name='budget_per_capita').to_csv(os.path.join(results, 'references', 'budget_per_capita.csv'))


#%% Liberal egalitarian institution

def liberal_egalitarian_reference(F, P, threshold_per_person, tax_rate):
    """Tax-and-transfer inside one scope. F and P: footprints and population of the actors.
    The total footprint of the scope does not change."""
    T = P * threshold_per_person                    # threshold of each actor
    excess = (F - T).clip(lower=0)                  # above the threshold
    shortfall = (T - F).clip(lower=0)               # below the threshold
    tax = tax_rate * excess

    revenue = tax.sum()
    need = shortfall.sum()
    if need == 0:                                   # nobody below: everything is surplus
        transfer = shortfall * 0
        surplus = revenue
    elif revenue >= need:                           # enough money: close every shortfall
        transfer = shortfall
        surplus = revenue - need
    else:                                           # not enough: close them pro rata
        transfer = shortfall * revenue / need
        surplus = 0

    dividend = surplus * P / P.sum()                # equal dividend per person
    R = F - tax + transfer + dividend

    if not np.isclose(R.sum(), F.sum()):
        raise ValueError('the LE redistribution does not conserve the total')
    return R


#%% Build the references for every scope, unit and state

for scope in scopes:
    P = to_scope(pop, scope)
    for unit in units:
        # EG reference: same budget for every person
        R_eg = P * budget[unit]
        R_eg.rename(f'EG_{unit}_{scope}').rename_axis('actor').to_csv(
            os.path.join(results, 'references', 'eg', f'EG_{unit}_{scope}.csv'))

        # LE reference: rebuilt from each state's own footprints
        for state in states:
            F = to_scope(read_footprint(state, unit), scope)
            R_le = liberal_egalitarian_reference(F, P, budget[unit], tax_rate)
            R_le.rename(f'LE_{state}_{unit}_{scope}').rename_axis('actor').to_csv(
                os.path.join(results, 'references', 'le', f'LE_{state}_{unit}_{scope}.csv'))

print('Saved EG and LE references')
