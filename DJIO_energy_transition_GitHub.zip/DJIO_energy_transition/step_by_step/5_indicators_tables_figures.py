# -*- coding: utf-8 -*-
"""
5_indicators_tables_figures.py

Step-by-step version of scripts/06_indicators_tables_figures.py, written with pandas for
readability. Compares the BAU and policy footprints with the three justice references and
makes the tables and the radar chart of the article.

Indicator = distance(policy) / distance(BAU)
    1 = as far as BAU, < 1 = closer to the benchmark, 0 = benchmark reached,
    NaN (dagger on the radar) = not defined, because the BAU distance is already 0
Distance = population-weighted root-mean-square gap per person (SF: only shortfalls count);
the EG distance is split into level and dispersion.

Tables (results_step_by_step/tables)
    indicators.csv                      main indicators + absolute distances (article Table 5)
    sf_absolute.csv                     who is below the SF threshold
    country_changes.csv                 actors moving closer / further (article Table 6)
    sensitivity_country_weights.csv     each country counts once
    sensitivity_territorial_EG_LE.csv   territorial (production-based) footprints
    sensitivity_normative.csv           tax rate x budget grid (radar whiskers)
    sensitivity_casal.csv               priority-based (Casal, 2011) variant of LE
    theil_decomposition.csv             world inequality: EU27 vs rest of world
    eu_footprint_by_origin.csv          EU footprint emitted inside / outside the EU
Figure: results_step_by_step/figures/fig_radar.png
"""

import pandas as pd
import numpy as np
import os
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

#%% Settings

path = os.path.dirname(os.path.abspath(__file__))
project = os.path.dirname(path)
file_pop = os.path.join(project, 'data', 'processed', 'pop_2015_exiobase.csv')
results = os.path.join(project, 'results_step_by_step')
tables = os.path.join(results, 'tables')
figures = os.path.join(results, 'figures')
for folder in [tables, figures, os.path.join(tables, 'country_detail')]:
    os.makedirs(folder, exist_ok=True)

EU27 = ["AT", "BE", "BG", "CY", "CZ", "DE", "DK", "EE", "ES", "FI", "FR", "GR", "HR", "HU",
        "IE", "IT", "LT", "LU", "LV", "MT", "NL", "PL", "PT", "RO", "SE", "SI", "SK"]
states = ['baseline', 'euref', 'stanford']
scenarios = ['euref', 'stanford']
units = ['co2', 'water']
scopes = ['EU', 'EUROW']

to_budget_unit = {'co2': 1e-3, 'water': 1e6}         # kg -> t, Mm3 -> m3
planetary_boundary = {'co2': 1.61, 'water': 574.0}
tax_rate = 0.5
sens_tax_rates = [0.25, 0.5, 0.75]
sens_budgets = ['planetary_boundary', 'current_world_average']


#%% Load everything (in t CO2 and m3 water)

def read_series(file):
    s = pd.read_csv(file, index_col=0).iloc[:, 0]
    s.index = s.index.astype(str)
    return s.astype(float)


pop = read_series(file_pop)
budget = read_series(os.path.join(results, 'references', 'budget_per_capita.csv'))

FP, TE, SF = {}, {}, {}
for state in states:
    for unit in units:
        k = to_budget_unit[unit]
        FP[(state, unit)] = read_series(os.path.join(results, 'footprints', 'consumption', f'FP_{state}_{unit}.csv')) * k
        TE[(state, unit)] = read_series(os.path.join(results, 'footprints', 'territorial', f'FP_{state}_{unit}.csv')) * k
        SF[(state, unit)] = read_series(os.path.join(results, 'references', 'sf', f'FP_SF_{unit}_{state}.csv')) * k

EG, LE = {}, {}
for scope in scopes:
    for unit in units:
        EG[(unit, scope)] = read_series(os.path.join(results, 'references', 'eg', f'EG_{unit}_{scope}.csv'))
        for state in states:
            LE[(state, unit, scope)] = read_series(os.path.join(results, 'references', 'le', f'LE_{state}_{unit}_{scope}.csv'))


def to_scope(s, scope):
    """EU: the 27 member states. EUROW: EU27 summed into one actor + the 22 other regions."""
    if scope == 'EU':
        return s.loc[EU27]
    return pd.concat([pd.Series({'EU27': s.loc[EU27].sum()}), s.drop(index=EU27)])


#%% Distance functions

def weights(P, weighting):
    """'population': each person counts once. 'country': each actor counts once."""
    if weighting == 'population':
        return P / P.sum()
    return P * 0 + 1 / len(P)


def rmsd(F, R, P, weighting='population'):
    """Root-mean-square gap per person between footprints F and reference R."""
    w = weights(P, weighting)
    gap = (F - R) / P
    return float(np.sqrt((w * gap ** 2).sum()))


def level_dispersion(F, R, P, weighting='population'):
    """rmsd^2 = level^2 + dispersion^2. Level = average gap; dispersion = spread of the gaps."""
    w = weights(P, weighting)
    gap = (F - R) / P
    level = float((w * gap).sum())
    dispersion = float(np.sqrt((w * (gap - level) ** 2).sum()))
    return level, dispersion


def sf_distance(F, S, P, weighting='population'):
    """Only shortfalls count, as a share of the threshold, squared (Foster-Greer-Thorbecke 2)."""
    w = weights(P, weighting)
    g = ((S - F) / S).clip(lower=0)
    return float(np.sqrt((w * g ** 2).sum()))


def ratio(d_policy, d_bau):
    """Indicator centred on 1; NaN when the BAU distance is 0 (not defined)."""
    if np.isclose(d_bau, 0):
        return np.nan
    return d_policy / d_bau


def indicators(F_bau, F_pol, P, R_eg, R_le_bau, R_le_pol, S_bau=None, S_pol=None, weighting='population'):
    """All indicators for one scenario x unit x scope."""
    row = {}
    if S_bau is not None:
        below_bau = set(P.index[F_bau < S_bau])
        below_pol = set(P.index[F_pol < S_pol])
        row['SF_abs_N_BAU'] = len(below_bau)
        row['SF_abs_N_POL'] = len(below_pol)
        row['SF_abs_dN'] = len(below_bau) - len(below_pol)
        row['SF_abs_H_BAU'] = P[list(below_bau)].sum() / P.sum()
        row['SF_abs_H_POL'] = P[list(below_pol)].sum() / P.sum()
        row['SF_left'] = ', '.join(sorted(below_bau - below_pol)) or '-'
        row['SF_entered'] = ', '.join(sorted(below_pol - below_bau)) or '-'
        row['SF_rel_D_BAU'] = sf_distance(F_bau, S_bau, P, weighting)
        row['SF_rel_D_POL'] = sf_distance(F_pol, S_pol, P, weighting)
        row['SF_rel'] = ratio(row['SF_rel_D_POL'], row['SF_rel_D_BAU'])

    level_bau, disp_bau = level_dispersion(F_bau, R_eg, P, weighting)
    level_pol, disp_pol = level_dispersion(F_pol, R_eg, P, weighting)
    row['EG_D_BAU'] = rmsd(F_bau, R_eg, P, weighting)
    row['EG_D_POL'] = rmsd(F_pol, R_eg, P, weighting)
    row['EG'] = ratio(row['EG_D_POL'], row['EG_D_BAU'])
    row['EG_level'] = ratio(abs(level_pol), abs(level_bau))
    row['EG_dispersion'] = ratio(disp_pol, disp_bau)

    row['LE_D_BAU'] = rmsd(F_bau, R_le_bau, P, weighting)
    row['LE_D_POL'] = rmsd(F_pol, R_le_pol, P, weighting)
    row['LE'] = ratio(row['LE_D_POL'], row['LE_D_BAU'])
    return row


def country_changes(F_bau, F_pol, R_bau, R_pol, P, weighting='population'):
    """Per actor: change of |gap per person| (negative = closer) and share of the BAU distance."""
    w = weights(P, weighting)
    gap_bau = (F_bau - R_bau) / P
    gap_pol = (F_pol - R_pol) / P
    contribution = w * gap_bau ** 2
    return pd.DataFrame({'gap_pc_BAU': gap_bau, 'gap_pc_POL': gap_pol,
                         'abs_change': gap_pol.abs() - gap_bau.abs(),
                         'share_of_D2_BAU': contribution / contribution.sum()})


def liberal_egalitarian_reference(F, P, threshold_per_person, tax_rate):
    """Same institution as in 4_justice_references.py (used here for the sensitivity analyses)."""
    T = P * threshold_per_person
    shortfall = (T - F).clip(lower=0)
    tax = tax_rate * (F - T).clip(lower=0)
    revenue, need = tax.sum(), shortfall.sum()
    if need == 0:
        transfer, surplus = shortfall * 0, revenue
    elif revenue >= need:
        transfer, surplus = shortfall, revenue - need
    else:
        transfer, surplus = shortfall * revenue / need, 0
    return F - tax + transfer + surplus * P / P.sum()


#%% Main indicators (Table 6), SF absolute (Appendix 2), country changes (Table 7)

def run(weighting):
    rows, rows_t7 = [], []
    for scen in scenarios:
        for unit in units:
            for scope in scopes:
                P = to_scope(pop, scope)
                F_bau = to_scope(FP[('baseline', unit)], scope).loc[P.index]
                F_pol = to_scope(FP[(scen, unit)], scope).loc[P.index]
                S_bau = to_scope(SF[('baseline', unit)], scope).loc[P.index]
                S_pol = to_scope(SF[(scen, unit)], scope).loc[P.index]
                R_eg = EG[(unit, scope)].loc[P.index]
                R_le_bau = LE[('baseline', unit, scope)].loc[P.index]
                R_le_pol = LE[(scen, unit, scope)].loc[P.index]

                key = {'Scenario': scen.upper(), 'Currency': unit, 'Scope': scope}
                rows.append({**key, **indicators(F_bau, F_pol, P, R_eg, R_le_bau, R_le_pol,
                                                 S_bau, S_pol, weighting)})

                # country detail for EG and LE
                for shape, (R_bau, R_pol) in {'EG': (R_eg, R_eg), 'LE': (R_le_bau, R_le_pol)}.items():
                    cc = country_changes(F_bau, F_pol, R_bau, R_pol, P, weighting)
                    if weighting == 'population':
                        cc.to_csv(os.path.join(tables, 'country_detail', f'{scen}_{shape}_{unit}_{scope}.csv'))
                    top3 = cc['share_of_D2_BAU'].sort_values(ascending=False).head(3)
                    rows_t7.append({**key, 'Shape': shape,
                                    'Improving': int((cc['abs_change'] < 0).sum()),
                                    'Worsening': int((cc['abs_change'] > 0).sum()),
                                    'Pct_improving': 100 * (cc['abs_change'] < 0).mean(),
                                    'Top3_share_of_BAU_distance': '; '.join(f'{k} {v:.0%}' for k, v in top3.items())})
    return pd.DataFrame(rows), pd.DataFrame(rows_t7)


table6, table7 = run('population')
sf_columns = ['Scenario', 'Currency', 'Scope', 'SF_abs_N_BAU', 'SF_abs_N_POL', 'SF_abs_H_BAU', 'SF_abs_H_POL',
              'SF_left', 'SF_entered']
table6[sf_columns].to_csv(os.path.join(tables, 'sf_absolute.csv'), index=False)
table6.drop(columns=['SF_left', 'SF_entered']).to_csv(os.path.join(tables, 'indicators.csv'), index=False)
table7.to_csv(os.path.join(tables, 'country_changes.csv'), index=False)
print(table6[['Scenario', 'Currency', 'Scope', 'SF_abs_dN', 'SF_rel', 'EG', 'EG_level', 'EG_dispersion', 'LE']].round(3))

# Sensitivity: each country counts once
table6_country, _ = run('country')
table6_country.drop(columns=['SF_left', 'SF_entered']).to_csv(
    os.path.join(tables, 'sensitivity_country_weights.csv'), index=False)


#%% Sensitivity: territorial accounting (EG and LE only)

rows = []
for scen in scenarios:
    for unit in units:
        for scope in scopes:
            P = to_scope(pop, scope)
            F_bau = to_scope(TE[('baseline', unit)], scope).loc[P.index]
            F_pol = to_scope(TE[(scen, unit)], scope).loc[P.index]
            R_le_bau = liberal_egalitarian_reference(F_bau, P, budget[unit], tax_rate)
            R_le_pol = liberal_egalitarian_reference(F_pol, P, budget[unit], tax_rate)
            rows.append({'Scenario': scen.upper(), 'Currency': unit, 'Scope': scope,
                         **indicators(F_bau, F_pol, P, EG[(unit, scope)].loc[P.index], R_le_bau, R_le_pol)})
pd.DataFrame(rows).to_csv(os.path.join(tables, 'sensitivity_territorial_EG_LE.csv'), index=False)


#%% Normative sensitivity: tax rate x budget definition

world_average = {unit: FP[('baseline', unit)].sum() / pop.sum() for unit in units}
budget_options = {'planetary_boundary': planetary_boundary, 'current_world_average': world_average}

rows = []
for b_name in sens_budgets:
    for tax in sens_tax_rates:
        for scen in scenarios:
            for unit in units:
                for scope in scopes:
                    P = to_scope(pop, scope)
                    F_bau = to_scope(FP[('baseline', unit)], scope).loc[P.index]
                    F_pol = to_scope(FP[(scen, unit)], scope).loc[P.index]
                    b = budget_options[b_name][unit]
                    R_le_bau = liberal_egalitarian_reference(F_bau, P, b, tax)
                    R_le_pol = liberal_egalitarian_reference(F_pol, P, b, tax)
                    r = indicators(F_bau, F_pol, P, P * b, R_le_bau, R_le_pol)
                    rows.append({'Budget': b_name, 'Tax_rate': tax, 'Scenario': scen.upper(), 'Currency': unit,
                                 'Scope': scope, 'Budget_per_capita': b, 'EG': r['EG'], 'LE': r['LE']})
sens = pd.DataFrame(rows)
sens.to_csv(os.path.join(tables, 'sensitivity_normative.csv'), index=False)
ranges = sens.groupby(['Scenario', 'Currency', 'Scope'])[['EG', 'LE']].agg(['min', 'max'])


#%% Theil decomposition: between EU27 and rest of world, and within each

def theil_decomposition(F, P, groups):
    """Population-weighted Theil T of footprints per person = within groups + between groups."""
    F = F[F > 0]
    P = P[F.index]
    mu = F.sum() / P.sum()
    phi = F / P
    T = float(((P / P.sum()) * (phi / mu) * np.log(phi / mu)).sum())
    result = {'T_total': T, 'T_between': 0.0}
    g = pd.Series(groups).reindex(F.index)
    for name in g.unique():
        Fg, Pg = F[g == name], P[g == name]
        mu_g = Fg.sum() / Pg.sum()
        S_g = Fg.sum() / F.sum()                      # group's share of the total footprint
        T_g = float(((Pg / Pg.sum()) * ((Fg / Pg) / mu_g) * np.log((Fg / Pg) / mu_g)).sum())
        result[f'T_within_{name}'] = T_g
        result[f'contrib_within_{name}'] = S_g * T_g
        result['T_between'] += S_g * np.log(mu_g / mu)
    result['share_between'] = result['T_between'] / T if T > 0 else np.nan
    return result


groups = {r: ('EU27' if r in EU27 else 'RoW') for r in pop.index}
rows = []
for state in states:
    for unit in units:
        rows.append({'State': state.upper(), 'Currency': unit, **theil_decomposition(FP[(state, unit)], pop, groups)})
theil = pd.DataFrame(rows)
theil.to_csv(os.path.join(tables, 'theil_decomposition.csv'), index=False)


#%% Casal (2011) variant of LE: revenue shared by priority, no threshold for receiving

def casal_rate(F, P, threshold_per_person):
    """Share of the footprint above the threshold that would have to go for the scope to fit
    its budget (Casal: 'the minimal tax rate necessary ...')."""
    T = P * threshold_per_person
    excess = (F - T).clip(lower=0).sum()
    overshoot = F.sum() - T.sum()
    return float(np.clip(overshoot / excess, 0, 1)) if excess > 0 else 0.0


def casal_reference(F, P, threshold_per_person, tax_rate, eta=1.0):
    """Tax above the threshold; revenue shared with weight = population x (footprint per person)^-eta."""
    T = P * threshold_per_person
    tax = tax_rate * (F - T).clip(lower=0)
    w = P * (F / P) ** (-eta)
    return F - tax + tax.sum() * w / w.sum()


main = table6.set_index(['Scenario', 'Currency', 'Scope'])
rows = []
for scen in scenarios:
    for unit in units:
        for scope in scopes:
            P = to_scope(pop, scope)
            F_bau = to_scope(FP[('baseline', unit)], scope).loc[P.index]
            F_pol = to_scope(FP[(scen, unit)], scope).loc[P.index]
            t_star = casal_rate(F_bau, P, budget[unit])
            row = {'Scenario': scen.upper(), 'Currency': unit, 'Scope': scope,
                   'casal_rate_BAU': t_star, 'casal_rate_POL': casal_rate(F_pol, P, budget[unit]),
                   'LE_main': main.loc[(scen.upper(), unit, scope), 'LE']}
            for name, rate in [('rate_star', t_star), ('rate_50', 0.5)]:
                d_bau = rmsd(F_bau, casal_reference(F_bau, P, budget[unit], rate), P)
                d_pol = rmsd(F_pol, casal_reference(F_pol, P, budget[unit], rate), P)
                row.update({f'LE_casal_{name}': ratio(d_pol, d_bau), f'D_BAU_{name}': d_bau, f'D_POL_{name}': d_pol})
            rows.append(row)
pd.DataFrame(rows).to_csv(os.path.join(tables, 'sensitivity_casal.csv'), index=False)


#%% Where the EU27 footprint is emitted: inside vs outside the EU

rows = []
for unit in units:
    inside, outside = {}, {}
    for state in states:
        o = pd.read_csv(os.path.join(results, 'footprints', 'origin', f'FP_EU_by_origin_{state}_{unit}.csv'),
                        index_col=0) * to_budget_unit[unit]
        o.index = o.index.astype(str)
        inside[state] = o.loc[o.index.isin(EU27)].values.sum()
        outside[state] = o.loc[~o.index.isin(EU27)].values.sum()
    for state in states:
        total = inside[state] + outside[state]
        change_in = inside[state] - inside['baseline']
        change_out = outside[state] - outside['baseline']
        rows.append({'State': state.upper(), 'Currency': unit, 'EU27_footprint': total,
                     'emitted_inside_EU': inside[state], 'emitted_outside_EU': outside[state],
                     'share_outside': outside[state] / total,
                     'change_inside_vs_BAU': change_in, 'change_outside_vs_BAU': change_out,
                     'share_of_change_outside': change_out / (change_in + change_out) if state != 'baseline' else np.nan})
pd.DataFrame(rows).to_csv(os.path.join(tables, 'eu_footprint_by_origin.csv'), index=False)


#%% Radar chart: SF-Rel, EG, LE for both scopes and units; BAU = circle at 1

axes = [(scope, unit, k) for scope in scopes for unit in units for k in ['SF_rel', 'EG', 'LE']]
labels = [f"{k.replace('_rel', '-Rel')}\n{scope} {'CO$_2$' if unit == 'co2' else 'water'}" for scope, unit, k in axes]
angles = np.linspace(0, 2 * np.pi, len(axes), endpoint=False)
style = {'EUREF': ('#E69F00', 'o'), 'STANFORD': ('#B2182B', 's')}

fig, ax = plt.subplots(figsize=(9, 9), subplot_kw=dict(polar=True))
undefined = set()
vmax = 1.2
for scen, (color, marker) in style.items():
    t = table6[table6['Scenario'] == scen].set_index(['Scope', 'Currency'])
    values = np.array([t.loc[(scope, unit), k] for scope, unit, k in axes], dtype=float)
    undefined |= set(np.where(np.isnan(values))[0])
    if np.isfinite(np.nanmax(values)):
        vmax = max(vmax, 1.1 * np.nanmax(values))
    plotted = np.where(np.isnan(values), 1.0, values)          # not defined: drawn at 1, empty marker
    ax.plot(np.r_[angles, angles[:1]], np.r_[plotted, plotted[:1]], color=color, lw=2, label=scen.title())
    ax.scatter(angles[~np.isnan(values)], plotted[~np.isnan(values)], color=color, marker=marker, s=55, zorder=3)
    ax.scatter(angles[np.isnan(values)], plotted[np.isnan(values)], facecolors='none', edgecolors=color,
               marker=marker, s=55, zorder=3)
    for i, (scope, unit, k) in enumerate(axes):               # whiskers: normative sensitivity range
        if k in ('EG', 'LE'):
            low = ranges.loc[(scen, unit, scope), (k, 'min')]
            high = ranges.loc[(scen, unit, scope), (k, 'max')]
            shift = 0.03 if scen == 'STANFORD' else -0.03
            ax.plot([angles[i] + shift] * 2, [low, high], color=color, lw=1.2, alpha=0.7)
            vmax = max(vmax, 1.1 * high)
ax.plot(np.r_[angles, angles[:1]], np.ones(len(angles) + 1), ls='--', color='grey', lw=1.2, label='BAU (= 1)')
ax.set_xticks(angles)
ax.set_xticklabels([l + (' †' if i in undefined else '') for i, l in enumerate(labels)], fontsize=8)
ax.set_ylim(0, vmax)
ax.set_rlabel_position(15)
ax.legend(loc='upper right', bbox_to_anchor=(1.25, 1.1), frameon=False)
ax.set_title('Distance to justice benchmarks relative to BAU\n(< 1 closer, 0 benchmark reached, † not defined;'
             ' lines: range over tax rates and budgets)', pad=24)
fig.tight_layout()
fig.savefig(os.path.join(figures, 'fig_radar.png'), dpi=300)
print('Tables and figure saved in', results)
