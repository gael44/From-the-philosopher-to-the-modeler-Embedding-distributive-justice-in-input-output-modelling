# -*- coding: utf-8 -*-
"""
2_dls_prices.py

Step-by-step version of scripts/02_dls_prices.py, written with pandas for readability.
World import price (2015) of every DLS item, in EUR per DLS unit, from UN Comtrade.

Comtrade download: HS codes of the DLS items, 2015, all reporters, partner World,
2nd partner World, flow Imports, mode of transport TOTAL, customs procedure TOTAL.
The downloaded files (xlsx or csv) go in data/raw/comtrade/.

Method notes
    - Year 2015 (same as EXIOBASE); EUR/USD 2015 = 0.9013.
    - Partner World: one row per importing country, no double counting.
    - One unit per HS code; net weight (kg) when the DLS item is in kg but Comtrade counts
      heads or pieces (live animals, T-shirts, bricks).
    - Extreme unit values trimmed (1% on each side), then quantity-weighted average
      (= total value / total quantity).
    - Conversion to the DLS unit (concrete per m3, gas per m3, electricity per kWh).

Output: results_step_by_step/processed/DLS_prices_2015.csv
"""

import pandas as pd
import os

#%% Settings

path = os.path.dirname(os.path.abspath(__file__))
project = os.path.dirname(path)
folder_comtrade = os.path.join(project, 'data', 'raw', 'comtrade')
out = os.path.join(project, 'results_step_by_step', 'processed')
os.makedirs(out, exist_ok=True)

eur_per_usd = 0.9013          # ECB 2015 annual average

# use the net weight (kg) instead of the Comtrade quantity for these HS codes
use_net_weight = [10229, 10410, 10511, 10594, 610910, 690410, 382450, 271121]

# multiply the price per Comtrade unit by this factor to get the price per DLS unit
unit_factor = {382450: 2400.0,      # concrete: EUR/kg -> EUR/m3 (2,400 kg/m3)
               271121: 0.75,        # natural gas: EUR/kg -> EUR/m3 (0.75 kg/m3)
               271600: 1 / 1000}    # electricity: EUR/1000 kWh -> EUR/kWh


#%% Load all the Comtrade files

files = [f for f in sorted(os.listdir(folder_comtrade)) if f.endswith('.xlsx') or f.endswith('.csv')]
tables = []
for f in files:
    if f.endswith('.xlsx'):
        tables.append(pd.read_excel(os.path.join(folder_comtrade, f)))
    else:
        tables.append(pd.read_csv(os.path.join(folder_comtrade, f), encoding='latin-1', low_memory=False))
trade = pd.concat(tables, ignore_index=True).drop_duplicates()
print(len(files), 'Comtrade files,', len(trade), 'rows')

# imports in 2015, partner World
trade = trade[(trade['flowCode'] == 'M') & (trade['refYear'] == 2015) & (trade['partnerCode'] == 0)].copy()
trade['cmdCode'] = trade['cmdCode'].astype(int)


#%% One price per HS code

rows = []
for hs, g in trade.groupby('cmdCode'):
    quantity = 'netWgt' if hs in use_net_weight else 'qty'

    # keep rows with a value and a quantity
    g = g[(g[quantity] > 0) & (g['primaryValue'] > 0)].copy()

    # remove the 1% lowest and 1% highest unit values
    g['unit_value'] = g['primaryValue'] / g[quantity]
    low = g['unit_value'].quantile(0.01)
    high = g['unit_value'].quantile(0.99)
    g = g[(g['unit_value'] >= low) & (g['unit_value'] <= high)]

    # quantity-weighted average = total value / total quantity, in EUR
    price = g['primaryValue'].sum() / g[quantity].sum() * eur_per_usd
    factor = unit_factor.get(hs, 1.0)

    rows.append({'HS': hs,
                 'cmdDesc': g['cmdDesc'].iloc[0],
                 'comtrade_unit': 'kg' if quantity == 'netWgt' else g['qtyUnitAbbr'].mode().iloc[0],
                 'EUR_per_comtrade_unit': price,
                 'factor_to_DLS_unit': factor,
                 'EUR_per_DLS_unit': price * factor,
                 'n_importers': len(g)})

prices = pd.DataFrame(rows).set_index('HS')
prices.to_csv(os.path.join(out, 'DLS_prices_2015.csv'))
print(prices[['comtrade_unit', 'EUR_per_DLS_unit', 'n_importers']].round(4))
