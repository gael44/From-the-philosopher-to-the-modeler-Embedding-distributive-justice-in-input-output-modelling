# -*- coding: utf-8 -*-
"""
1_electricity_scenarios.py

Step-by-step version of scripts/03_electricity_scenarios.py, written with pandas for
readability. It gives the same results (checked by 7_compare_with_main_scripts.py).

What it does
    1. Read the electricity generation (GWh) of the scenarios and build the mixes
    2. Read EXIOBASE 3.7 (2015, industry by industry) and compute the output x
    3. Read the CO2, water and energy extensions and apply the five processing steps for
       electricity data (SI, Section S3)
    4. For each model scenario (baseline = 2015 mix, euref, stanford):
         - give a recipe to technologies with no 2015 output (proxy country)
         - re-split every buyer's electricity purchases with the generation mix (GWh shares)
         - compute L, footprints, multipliers, and where the EU footprint is emitted

Method notes
    - The mix is applied by re-splitting each buyer's purchases (column of A, column of Y)
      with GWh shares; BAU uses the same procedure with the 2015 mix.
    - Footprints are consumption-based (M @ Y) plus household direct emissions.

Outputs (in results_step_by_step/): footprints, multipliers, x_2015.csv
"""

import pandas as pd
import numpy as np
import os

#%% Settings

path = os.path.dirname(os.path.abspath(__file__))     # step_by_step folder
project = os.path.dirname(path)                        # project folder

path_exio = os.path.join(project, 'data', 'raw', 'exiobase', 'IOT_2015_ixi')
file_gen = os.path.join(project, 'data', 'raw', 'scenarios', 'Scenarios.xlsx')
file_proxy = os.path.join(project, 'data', 'raw', 'scenarios', 'technical_coefficient_substitution_Cerny2022.xlsx')
out = os.path.join(project, 'results_step_by_step')

EU27 = ["AT", "BE", "BG", "CY", "CZ", "DE", "DK", "EE", "ES", "FI", "FR", "GR", "HR", "HU",
        "IE", "IT", "LT", "LU", "LV", "MT", "NL", "PL", "PT", "RO", "SE", "SI", "SK"]

# rows of the EXIOBASE satellite account that we sum
extension_rows = {
    'co2': ['CO2 - combustion - air', 'CO2 - non combustion', 'CO2 - agriculture - peat decay - air',
            'CO2 - waste - biogenic - air', 'CO2 - waste - fossil - air'],
    'water': ['Water Consumption Blue - Agriculture', 'Water Consumption Blue - Livestock',
              'Water Consumption Blue - Manufacturing', 'Water Consumption Blue - Electricity',
              'Water Consumption Blue - Domestic'],
    'energy': ['Energy Carrier Net Total'],            # only used for the validation
    'energy_nene': ['Energy Carrier Net NENE'],        # non-energy use (validation)
    'energy_loss': ['Energy Carrier Net LOSS'],        # losses (validation)
}

min_output = 1.0      # M EUR: below this 2015 output, a technology is treated as absent

# direct emission factors (t CO2 per MWh), used for correction 4 and 5
emission_factor = {'coal': 0.76, 'gas': 0.37, 'petroleum': 0.65, 'biomass': 0.05, 'Geothermal': 0.04,
                   'nuclear': 0.0, 'hydro': 0.0, 'wind': 0.0, 'solar': 0.0, 'tide': 0.0}

non_combustion = ['wind', 'solar', 'tide', 'hydro', 'nuclear']
combustion = ['coal', 'gas', 'petroleum', 'biomass', 'nec']

for folder in ['footprints/consumption', 'footprints/territorial', 'footprints/origin', 'multipliers']:
    os.makedirs(os.path.join(out, folder), exist_ok=True)


#%% 1. Electricity generation data (GWh) and generation mixes

wind_industries = ['Production of electricity by wind offshore', 'Production of electricity by wind onshore']
solar_industries = ['Production of electricity by solar photovoltaic residential',
                    'Production of electricity by solar photovoltaic utility']


def read_generation(sheet):
    """Generation (GWh) in 2015 and 2050 by EU country and technology, wind and solar collapsed."""
    df = pd.read_excel(file_gen, sheet_name=sheet)

    # Data check: stop if a technology is more than 50x its country's total 2015 generation
    total_2015 = df.groupby('Country.Code')['gen2015'].transform('sum')
    too_big = df[['gen2015', 'gen2050']].max(axis=1) > 50 * total_2015
    if too_big.any():
        print(df.loc[too_big, ['Country.Code', 'Industry.Name', 'gen2015', 'gen2050']])
        raise ValueError(sheet + ': implausible generation values. Use the unmodified Scenarios.xlsx of Cerny et al. (2022).')

    # keep the EU27 only
    df = df[df['Country.Code'].isin(EU27)].copy()

    # collapse wind and solar into the single EXIOBASE sectors
    df['sector'] = df['Industry.Name']
    df.loc[df['sector'].isin(wind_industries), 'sector'] = 'Production of electricity by wind'
    df.loc[df['sector'].isin(solar_industries), 'sector'] = 'Production of electricity by solar photovoltaic'

    gen = df.groupby(['Country.Code', 'sector'])[['gen2015', 'gen2050']].sum()
    gen.index.names = ['region', 'sector']
    return gen


def generation_mix(gen):
    """Share of each technology in the country's generation (sums to 1 per country)."""
    country_total = gen.groupby(level='region').transform('sum')
    return (gen / country_total).fillna(0)


gen_euref = read_generation('euref_det')
gen_stanford = read_generation('stanford_det')

# The mix is in GWh (not in money). BAU = 2015 mix (identical in both sheets)
mixes = {'baseline': generation_mix(gen_euref['gen2015']),
         'euref': generation_mix(gen_euref['gen2050']),
         'stanford': generation_mix(gen_stanford['gen2050'])}

gen2015 = gen_euref['gen2015']


#%% 2. EXIOBASE 2015 ixi: A, Y and the base year output X

print('Reading EXIOBASE ...')
A = pd.read_csv(os.path.join(path_exio, 'A.txt'), sep='\t', header=[0, 1], index_col=[0, 1])
A = A.sort_index(axis=0).sort_index(axis=1)

Y = pd.read_csv(os.path.join(path_exio, 'Y.txt'), sep='\t', header=[0, 1], index_col=[0, 1])
Y = Y.sort_index(axis=1).reindex(A.index)

sectors = A.index.get_level_values(1).unique()
regions = A.index.get_level_values(0).unique()

I = np.eye(A.shape[0])
L = np.linalg.inv(I - A.values)                       # Leontief inverse
X = pd.Series(L @ Y.sum(axis=1).values, index=A.index)  # total output (M EUR)
del L
X.rename('x_2015_MEUR').to_csv(os.path.join(out, 'multipliers', 'x_2015.csv'))


#%% 3. Extensions and the 5 corrections to EXIOBASE

F = pd.read_csv(os.path.join(path_exio, 'satellite', 'F.txt'), sep='\t', header=[0, 1], index_col=0,
                low_memory=False)
F = F.apply(pd.to_numeric, errors='coerce')

F_hh = pd.read_csv(os.path.join(path_exio, 'satellite', 'F_hh.txt'), sep='\t', header=[0, 1], index_col=0,
                   low_memory=False)
F_hh = F_hh.apply(pd.to_numeric, errors='coerce')


def select_rows(F, names):
    """Sum of the satellite rows whose name contains one of the given texts."""
    keep = [row for row in F.index if any(name in row for name in names)]
    return F.loc[keep].sum(axis=0)


# total direct emissions (kg, Mm3, TJ) by sector, and household direct emissions by region
total = {}
household = {}
for unit, names in extension_rows.items():
    total[unit] = select_rows(F, names).reindex(A.index).fillna(0)
    household[unit] = select_rows(F_hh, names).groupby(level=0).sum()

electricity_sectors = [s for s in sectors if s.startswith('Production of electricity')]

# --- Correction 3: CO2 booked on technologies that burn no fuel (wind, PV, hydro...) ---
# is moved to the fuel-burning technologies of the same country, pro rata to their CO2
moved_total = 0
for r in regions:
    non = [(r, s) for s in electricity_sectors if any(t in s for t in non_combustion)]
    com = [(r, s) for s in electricity_sectors if any(t in s for t in combustion)]
    moved = total['co2'].loc[non].sum()
    base = total['co2'].loc[com].sum()
    if moved > 0 and base > 0:
        total['co2'].loc[com] += moved * total['co2'].loc[com] / base
        total['co2'].loc[non] = 0
        moved_total += moved
print(f'Correction 3: {moved_total / 1e9:.1f} Mt CO2 moved from non-combustion to combustion technologies')

# --- Correction 1: intensity = emissions / output, but 0 where output is 0 (no inf) ---
intensity = {}
for unit in extension_rows:
    intensity[unit] = (total[unit] / X).where(X > 1e-9, 0)

# --- Corrections 4 and 5 (EU27 only): physical split of electricity CO2 ---
f = intensity['co2']
for c in EU27:
    g = gen2015.loc[c]                                        # GWh by technology
    techs = [t for t in g.index if (c, t) in A.index]
    ef = pd.Series({t: next(v for k, v in emission_factor.items() if k in t) for t in techs})
    rows = [(c, t) for t in techs]

    co2_electricity = (f.loc[rows] * X.loc[rows]).sum()                # kg, as booked in EXIOBASE
    co2_expected = (g[techs] * ef).sum() * 1e6                 # GWh x t/MWh -> kg

    # Correction 4: power-plant CO2 booked under 'Steam and hot water supply' (CHP)
    steam = (c, 'Steam and hot water supply')
    if steam in A.index and co2_electricity < co2_expected and X.loc[steam] > 0:
        moved = min(co2_expected - co2_electricity, f.loc[steam] * X.loc[steam])
        f.loc[steam] -= moved / X.loc[steam]
        co2_electricity += moved
        print(f'Correction 4: {c}: {moved / 1e9:.1f} Mt CO2 moved from steam and hot water supply')

    # Correction 5: re-split the country's electricity CO2 with GWh x emission factor
    if (g[techs] * ef).sum() == 0 or co2_electricity == 0:
        continue
    price = X.loc[rows].sum() / g[techs].sum()                 # M EUR per GWh
    f.loc[rows] = co2_electricity * ef.values / (g[techs] * ef).sum() / price
intensity['co2'] = f


#%% 4a. Functions used for every state

proxies = pd.read_excel(file_proxy, sheet_name='new')


def patch_missing_recipes(A_s, f_s, mix, state):
    """Technologies with a share in the mix but (almost) no output in 2015 get the input column
    of a proxy country (Cerny et al. 2022, section 8.3). Changes A_s and f_s in place."""
    for (c, t), share in mix.items():
        if share == 0 or X.loc[(c, t)] >= min_output:
            continue

        # proxy listed by Cerny et al., if it really produces that technology
        p = proxies[(proxies['country missing a technology in 2015'] == c) & (proxies['technology'] == t)]
        proxy = None
        if len(p) > 0 and X.loc[(p['Replacement country'].iloc[0], t)] >= min_output:
            proxy = p['Replacement country'].iloc[0]
        if proxy is None:                                      # else: largest EU producer
            proxy = max(EU27, key=lambda r: X.loc[(r, t)])
            print(f'  no proxy listed for {c} / {t}: using {proxy}')

        # copy the proxy's recipe; domestic inputs move to the host only if the host makes them
        col = A_s[(proxy, t)].copy()
        for s in sectors:
            if X.loc[(c, s)] >= min_output:
                col.loc[(c, s)] += col.loc[(proxy, s)]
                col.loc[(proxy, s)] = 0
        A_s[(c, t)] = col

        # water and energy intensities from the proxy (CO2 keeps the host's own value)
        for unit in f_s:
            if unit != 'co2':
                f_s[unit].loc[(c, t)] = f_s[unit].loc[(proxy, t)]
        print(f'  {state}: {c} / {t} uses the recipe of {proxy}')


def apply_mix(M, mix):
    """Each buyer (column of A or Y) keeps what it buys from country c's electricity
    sectors in total, re-split with c's generation shares (one price per kWh)."""
    for c in mix.index.get_level_values('region').unique():
        shares = mix.loc[c]
        rows = [(c, t) for t in shares.index]
        purchases = M.loc[rows].sum(axis=0)                   # total per buyer
        M.loc[rows] = np.outer(shares.values, purchases.values)


#%% 4b. The three states: baseline (2015 mix), euref, stanford

eu_columns = [col for col in Y.columns if col[0] in EU27]

for state, mix in mixes.items():
    print(f'\n=== {state} ===')
    A_s = A.copy()
    Y_s = Y.copy()
    f_s = {unit: intensity[unit].copy() for unit in intensity}

    patch_missing_recipes(A_s, f_s, mix, state)
    apply_mix(A_s, mix)
    apply_mix(Y_s, mix)

    # Leontief inverse and output of this state
    L_s = np.linalg.inv(I - A_s.values)
    L_s = pd.DataFrame(L_s, index=A.index, columns=A.index)
    del A_s
    x_s = L_s @ Y_s.sum(axis=1)

    # EU27 final demand per consuming country (for 'where is the EU footprint emitted?')
    y_eu = Y_s[eu_columns].T.groupby(level=0).sum().T
    X_eu = L_s @ y_eu                                          # output needed by each EU country

    for unit in extension_rows:
        M = f_s[unit] @ L_s                                    # multipliers: f L
        M.rename(f'M_{state}_{unit}').to_csv(os.path.join(out, 'multipliers', f'M_{state}_{unit}.csv'))
        if unit not in ['co2', 'water']:
            continue

        # consumption-based footprint = M . Y (7 final demand columns per region) + household direct
        consumption = (M @ Y_s).groupby(level=0).sum() + household[unit]
        territorial = (f_s[unit] * x_s).groupby(level=0).sum() + household[unit]
        consumption.rename(f'FP_{state}_{unit}').rename_axis('region').to_csv(
            os.path.join(out, 'footprints', 'consumption', f'FP_{state}_{unit}.csv'))
        territorial.rename(f'TE_{state}_{unit}').rename_axis('region').to_csv(
            os.path.join(out, 'footprints', 'territorial', f'FP_{state}_{unit}.csv'))

        # EU footprint by region of emission (rows) and EU consuming country (columns)
        by_origin = X_eu.mul(f_s[unit], axis=0).groupby(level=0).sum()
        for c in y_eu.columns:
            by_origin.loc[c, c] += household[unit].get(c, 0)  # household emissions happen at home
        by_origin.rename_axis('region_of_emission').to_csv(
            os.path.join(out, 'footprints', 'origin', f'FP_EU_by_origin_{state}_{unit}.csv'))

    del L_s, Y_s
    print(f'{state}: done')

print('\nFootprints and multipliers saved in', out)
