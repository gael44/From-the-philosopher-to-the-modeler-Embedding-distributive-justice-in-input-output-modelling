# -*- coding: utf-8 -*-
"""Writes a small synthetic data set in the EXIOBASE / Scenarios / DLS formats into a project
folder, so the pipeline (scripts 03-06) can be tested without the real data.
Usage: python make_synthetic_data.py <project_root> [--null]   (--null: Stanford 2050 mix = 2015 mix)"""
import sys
from pathlib import Path
import numpy as np
import pandas as pd

root = Path(sys.argv[1]); null = '--null' in sys.argv
sys.path.insert(0, str(root)); import config as cfg
rng = np.random.default_rng(42)
pop = pd.read_csv(Path(__file__).with_name('pop_2015_exiobase.csv'), index_col=0).iloc[:, 0]
regions, EU = sorted(pop.index), cfg.EU27
COAL, WIND = 'Production of electricity by coal', 'Production of electricity by wind'
sectors = [COAL, WIND, 'Manufacture', 'Services']
idx = pd.MultiIndex.from_product([regions, sectors], names=['region', 'sector']); n = len(idx)
A = np.zeros((n, n))
for i in range(len(regions)):
    b = slice(4 * i, 4 * i + 4); A[b, b] = rng.uniform(0.02, 0.15, (4, 4))
A = pd.DataFrame(A + rng.uniform(0, 0.002, (n, n)), index=idx, columns=idx)
yc = pd.MultiIndex.from_product([regions, ['Households', 'Government']], names=['region', 'category'])
Y = pd.DataFrame(0.0, index=idx, columns=yc)
for r in regions:
    sc = pop[r] / 1e6 * (25 if r in EU + ['US', 'AU', 'CA', 'GB', 'JP'] else 4)
    Y.loc[r, (r, 'Households')] = sc * np.array([1, 1, 20, 40]) * rng.uniform(.8, 1.2, 4)
    Y.loc[r, (r, 'Government')] = sc * np.array([.2, .2, 3, 15])
    Y.loc[:, (r, 'Households')] += rng.uniform(0, .02 * sc, n)
A.loc[('MT', WIND), :] = 0; A.loc[:, ('MT', WIND)] = 0; Y.loc[('MT', WIND), :] = 0     # MT: no wind in 2015
x = pd.Series(np.linalg.solve(np.eye(n) - A.values, Y.sum(axis=1).values), index=idx)
inten = np.select([idx.get_level_values(1) == COAL, idx.get_level_values(1) == WIND], [6e6, 2e4], 3e5)
F = pd.DataFrame([inten * x.values * .9, inten * x.values * .1, 4e-6 * x.values * (inten / 3e5), rng.uniform(0, 1, n)],
                 index=['CO2 - combustion - air', 'CO2 - waste - biogenic - air',
                        'Water Consumption Blue - Agriculture - rice', 'CH4 - combustion - air'], columns=idx)
F_hh = pd.DataFrame([[pop[r] * 1.5e3 for r in regions for _ in range(2)], [pop[r] * 2e-6 for r in regions for _ in range(2)]],
                    index=['CO2 - combustion - air', 'Water Consumption Blue - Domestic'], columns=yc)
cfg.EXIOBASE_DIR.joinpath('satellite').mkdir(parents=True, exist_ok=True)
A.to_csv(cfg.EXIOBASE_DIR / 'A.txt', sep='\t'); Y.to_csv(cfg.EXIOBASE_DIR / 'Y.txt', sep='\t')
F.to_csv(cfg.EXIOBASE_DIR / 'satellite' / 'F.txt', sep='\t'); F_hh.to_csv(cfg.EXIOBASE_DIR / 'satellite' / 'F_hh.txt', sep='\t')

def sheet(wind_2050):
    rows = []
    for c in EU + ['GB']:
        tot = 1000.0
        for name, s15, s50 in [(COAL, .8, 1 - wind_2050), ('Production of electricity by wind onshore', .15, wind_2050 * .6),
                               ('Production of electricity by wind offshore', .05, wind_2050 * .4)]:
            if c == 'MT' and 'wind' in name: s15 = 0
            if null: s50 = s15
            rows.append({'Country.Code': c, 'Industry.Name': name, 'Industry.Code': '-', 'gen2015': tot * s15,
                         'gen2020': tot * s50, 'gen2050': tot * s50, 'X2015': tot * s15 / 10, 'X2050': tot * s50 / 10})
    return pd.DataFrame(rows)
cfg.SCENARIOS_FILE.parent.mkdir(parents=True, exist_ok=True)
with pd.ExcelWriter(cfg.SCENARIOS_FILE) as w:
    sheet(.5).to_excel(w, sheet_name='euref_det', index=False); sheet(.95).to_excel(w, sheet_name='stanford_det', index=False)
dls = pd.DataFrame({'ReferenceProduct': ['steel', 'laptop', 'doctor', 'natural gas, high pressure', 'bus'],
                    'Unit': ['kg', 'unit', 'unit', 'm3', 'person*km'], 'Quantity': [10, 1, 1, 143, 900],
                    'HS': [720690, 847130, None, 271121, None], 'Price': [30, 250, None, 0.42, None],
                    'Values': [300, 250, 600, 60, 0],
                    'Exiobase sector': ['Manufacture', 'Manufacture', 'Services', 'Manufacture', None]})
cfg.DLS_FILE.parent.mkdir(parents=True, exist_ok=True)
with pd.ExcelWriter(cfg.DLS_FILE) as w:
    pd.DataFrame([['DLS flow']]).to_excel(w, sheet_name='DLS-Exiobase', index=False, header=False)
    dls.to_excel(w, sheet_name='DLS-Exiobase', index=False, startrow=1)
cfg.PROCESSED.mkdir(parents=True, exist_ok=True); pop.to_csv(cfg.POP_FILE)
print('synthetic data written to', root, '(null test)' if null else '')
