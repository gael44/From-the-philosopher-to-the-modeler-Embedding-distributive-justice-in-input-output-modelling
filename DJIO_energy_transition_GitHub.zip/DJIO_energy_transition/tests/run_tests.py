# -*- coding: utf-8 -*-
"""Runs the pipeline (scripts 03-07) twice on synthetic data in a temporary copy of the project:
1. null test: Stanford 2050 mix = 2015 mix -> Stanford footprints identical to BAU, indicators = 1
2. normal run: all tables and the radar chart are produced.
Usage: python tests/run_tests.py"""
import shutil, subprocess, sys, tempfile
from pathlib import Path
import numpy as np
import pandas as pd

project = Path(__file__).resolve().parents[1]
scripts = ['03_electricity_scenarios.py', '04_sufficiency_threshold.py',
           '05_justice_references.py', '06_indicators_tables_figures.py', '07_validation.py']

def run(null):
    tmp = Path(tempfile.mkdtemp()) / 'project'
    shutil.copytree(project, tmp, ignore=shutil.ignore_patterns('data', 'results', '__pycache__'))
    (tmp / 'data' / 'raw' / 'scenarios').mkdir(parents=True)
    shutil.copy(project / 'data' / 'raw' / 'scenarios' / 'technical_coefficient_substitution_Cerny2022.xlsx',
                tmp / 'data' / 'raw' / 'scenarios')
    subprocess.run([sys.executable, str(tmp / 'tests' / 'make_synthetic_data.py'), str(tmp)] + (['--null'] if null else []), check=True)
    for s in scripts:
        r = subprocess.run([sys.executable, str(tmp / 'scripts' / s)], capture_output=True, text=True, env={'MPLBACKEND': 'Agg', **__import__('os').environ})
        if r.returncode:
            print(r.stdout, r.stderr); raise SystemExit(f'FAILED: {s}')
    return tmp

t = run(null=True)
for u in ['co2', 'water']:
    b = pd.read_csv(t / 'results/footprints/consumption' / f'FP_baseline_{u}.csv', index_col=0).iloc[:, 0]
    s = pd.read_csv(t / 'results/footprints/consumption' / f'FP_stanford_{u}.csv', index_col=0).iloc[:, 0]
    assert np.allclose(s, b, rtol=1e-12), f'null test failed for {u}'
tab = pd.read_csv(t / 'results/tables/indicators.csv')
st = tab[tab.Scenario == 'STANFORD'][['EG', 'LE']].values
assert np.allclose(st[~np.isnan(st)], 1.0), 'null test: indicators should be 1'
print('TEST 1 passed: unchanged mix reproduces BAU, indicators = 1')

t = run(null=False)
for f in ['indicators.csv', 'sensitivity_country_weights.csv', 'sensitivity_territorial_EG_LE.csv',
          'country_changes.csv', 'sf_absolute.csv',
          'sensitivity_normative.csv', 'theil_decomposition.csv',
          'sensitivity_casal.csv', 'eu_footprint_by_origin.csv']:
    assert (t / 'results/tables' / f).exists(), f
assert (t / 'results/figures/fig_radar.png').exists()
print('TEST 2 passed: full pipeline produces all tables and the radar chart')
print('Output of the normal run kept in', t)
