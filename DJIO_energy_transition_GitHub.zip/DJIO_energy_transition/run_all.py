# -*- coding: utf-8 -*-
"""Runs the whole pipeline in order. Usage: python run_all.py [first_script_number]
e.g. `python run_all.py 4` reruns scripts 04-08 after a change that does not touch EXIOBASE."""
import os, subprocess, sys
from pathlib import Path

first = int(sys.argv[1]) if len(sys.argv) > 1 else 1
scripts = sorted(p for p in (Path(__file__).parent / 'scripts').glob('[0-9][0-9]_*.py') if int(p.name[:2]) >= first)
env = {**os.environ, 'MPLBACKEND': 'Agg'}
for s in scripts:
    if s.name.startswith('01') and not any((Path(__file__).parent / 'data/raw/population').glob('*.csv')):
        print('skip 01: no WPP file; using data/processed/pop_2015_exiobase.csv')
        continue
    print(f'\n=== {s.name} ===', flush=True)
    subprocess.run([sys.executable, str(s)], check=True, env=env)
print('\nAll done. Tables in results/tables, figures in results/figures.')
