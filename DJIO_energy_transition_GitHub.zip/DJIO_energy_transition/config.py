# -*- coding: utf-8 -*-
"""
config.py - every path, data choice and normative parameter of the DJ/IO study in ONE place.
Change a choice here, rerun the scripts in /scripts in numerical order, and all results follow.
"""
from pathlib import Path

#%% Folders -----------------------------------------------------------------------------
ROOT = Path(__file__).resolve().parent
RAW = ROOT / 'data' / 'raw'
PROCESSED = ROOT / 'data' / 'processed'
RESULTS = ROOT / 'results'

EXIOBASE_DIR = RAW / 'exiobase' / 'IOT_2015_ixi'                  # pymrio text format
SCENARIOS_FILE = RAW / 'scenarios' / 'Scenarios.xlsx'               # unmodified file of Cerny et al. (2022)
PROXY_FILE = RAW / 'scenarios' / 'technical_coefficient_substitution_Cerny2022.xlsx'
DLS_FILE = RAW / 'dls' / 'DLS_requirements_Exiobase.xlsx'
COMTRADE_DIR = RAW / 'comtrade'                                     # Comtrade 2015 downloads (.xlsx/.csv)
WPP_FILE = RAW / 'population' / 'WPP2024_Demographic_Indicators_Medium.csv'

POP_FILE = PROCESSED / 'pop_2015_exiobase.csv'
PRICES_FILE = PROCESSED / 'DLS_prices_2015.csv'

FOOTPRINTS = RESULTS / 'footprints'          # consumption-based (main) and territorial (sensitivity)
MULTIPLIERS = RESULTS / 'multipliers'        # M = f L per state, used by the SF threshold
REFERENCES = RESULTS / 'references'          # SF, EG and LE justice references
TABLES = RESULTS / 'tables'
FIGURES = RESULTS / 'figures'

#%% Study design ------------------------------------------------------------------------
YEAR = 2015
STATES = ['baseline', 'euref', 'stanford']
SCENARIOS = ['euref', 'stanford']
CURRENCIES = ['co2', 'water']
SCOPES = ['EU', 'EUROW']                      # EU27 (27 actors); EU27 as one actor + 22 regions (23)

EU27 = ["AT", "BE", "BG", "CY", "CZ", "DE", "DK", "EE", "ES", "FI", "FR", "GR", "HR", "HU",
        "IE", "IT", "LT", "LU", "LV", "MT", "NL", "PL", "PT", "RO", "SE", "SI", "SK"]

#%% Environmental extensions (EXIOBASE satellite) ----------------------------------------
# CO2 includes biogenic waste CO2 (kept on purpose: counted in inventories' waste sector).
CO2_KEYWORDS = ['CO2 - combustion - air', 'CO2 - non combustion',
                'CO2 - agriculture - peat decay - air',
                'CO2 - waste - biogenic - air', 'CO2 - waste - fossil - air']
WATER_KEYWORDS = ['Water Consumption Blue - Agriculture', 'Water Consumption Blue - Livestock',
                  'Water Consumption Blue - Manufacturing', 'Water Consumption Blue - Electricity',
                  'Water Consumption Blue - Domestic']
ENERGY_KEYWORDS = ['Energy Carrier Net Total']          # TJ; used only for validation (07)
# EXIOBASE 'net' energy = final use + conversion/distribution losses + non-energy use (feedstocks),
# so it is above final energy. The two parts below are subtracted in the validation (07).
ENERGY_PART_KEYWORDS = {'energy_nene': ['Energy Carrier Net NENE'], 'energy_loss': ['Energy Carrier Net LOSS']}
# Units confirmed in satellite/unit.txt: CO2 in kg, blue water in Mm3 -> budgets in t and m3
TO_BUDGET_UNIT = {'co2': 1e-3, 'water': 1e6}
INCLUDE_HOUSEHOLD_DIRECT = True               # add F_hh (CO2-only list) to footprints

#%% Electricity scenarios ---------------------------------------------------------------
# The mix is computed from GENERATION (GWh); BAU uses the 2015 generation mix with the same
# procedure, so policy vs BAU isolates the change of mix (null test: 2015 mix = BAU).
DATA_CHECK_MAX_RATIO = 50                     # stop if a technology > 50x its country's 2015 total
# EXIOBASE contains residual electricity sectors with almost no output but non-zero emissions
# (e.g. IT tide: 650 EUR of output, 2 kt CO2 -> 3e12 kg/MEUR). A technology with less than this
# 2015 output is treated as ABSENT and gets the proxy recipe (Cerny et al., 2022, Section 8.3).
MIN_OUTPUT_MEUR = 1.0
# EXIOBASE 3.7 also books fuel-combustion CO2 on technologies that burn no fuel (e.g. PL wind
# 2.5 Mt, DE PV 2.0 Mt, CZ wind 62 t CO2 per kEUR, more than coal). Expanding these technologies
# would then RAISE emissions. If True, the direct CO2 of these technologies is moved to the
# same country's combustion technologies (pro rata), so national totals are unchanged.
REALLOCATE_NONCOMBUSTION_CO2 = True
NONCOMBUSTION_TECH = ['wind', 'solar', 'tide', 'hydro', 'nuclear']   # geothermal kept: real reservoir CO2 (e.g. IT)
COMBUSTION_TECH = ['coal', 'gas', 'petroleum', 'biomass', 'nec']
# EXIOBASE's split of a country's electricity CO2 across technologies is not physical either
# (e.g. SI coal 0.64 kg CO2/EUR vs SI oil 69 kg/EUR), so replacing coal by gas can RAISE CO2.
# If True, for EU27 each country's electricity CO2 total (EXIOBASE) is re-split across
# technologies with its 2015 generation (GWh, Scenarios.xlsx) x these direct emission factors,
# with the uniform price per kWh used for the mix. National totals are unchanged.
EF_ALLOCATION_EU = True
# EXIOBASE 3.7 books most power-plant CO2 of some countries under 'Steam and hot water supply'
# (CHP): Poland 142 Mt there vs 5 Mt on electricity. If True, for EU27, when the electricity
# sectors carry less CO2 than generation x emission factors implies, the shortfall is moved from
# the same country's steam and hot water sector (at most its whole CO2). National totals unchanged.
MOVE_CHP_CO2_TO_ELECTRICITY = True
ELECTRICITY_EF_T_PER_MWH = {          # direct (stack) emissions, fossil CO2 only
    'coal': 0.76,                     # IPCC AR5 WGIII Annex III, Table A.III.2, median PC coal
    'gas': 0.37,                      # idem, median gas combined cycle
    'petroleum': 0.65,                # IPCC 2006 oil 74 t/TJ at ~41% efficiency
    'biomass': 0.05,                  # fossil share of waste incineration (biogenic excluded)
    'Geothermal': 0.04,               # non-condensable gases, world average order of magnitude
    'nuclear': 0.0, 'hydro': 0.0, 'wind': 0.0, 'solar': 0.0, 'tide': 0.0,
}

#%% Justice references --------------------------------------------------------------------
PB_PER_CAPITA = {'co2': 1.61, 'water': 574.0}  # t CO2 and m3 blue water per person per year (O'Neill et al., 2018)
# Budget used by EG (equal share) and as LE threshold:
#  'binding'            = min(planetary-boundary share, current world average)  [MAIN]
#                         -> CO2 1.61 t (boundary binding), water = world average (~159 m3),
#                         because water use is far below its boundary: an equal division of the
#                         unused part of the budget is not a distributive claim.
#  'planetary_boundary' = PB_PER_CAPITA for both resources
BUDGET_RULE = 'binding'
LE_TAX_RATE = 0.5
LE_SURPLUS_RULE = 'per_capita'                 # 'per_capita' (equal dividend) or 'contributors'
LE_REFERENCE_STATE = 'own'                     # LE reference rebuilt from each state's footprints
CASAL_ETA = 1.0                                # priority weight ~ (per-capita footprint)^-eta (Casal variant)

#%% Sufficiency (DLS) ----------------------------------------------------------------------
DLS_PRICE_FACTOR = 1.0                         # converts DLS price year to 2015 EUR if needed
USE_COMTRADE_2015_PRICES = True                # 04: price = Comtrade 2015 (script 02) instead of the sheet's
# Comtrade quantity basis per HS code: net weight (kg) when the DLS item is in kg but Comtrade
# counts heads or pieces
DLS_PRICE_BASIS = {10229: 'netWgt', 10410: 'netWgt', 10511: 'netWgt', 10594: 'netWgt',
                   610910: 'netWgt', 690410: 'netWgt', 382450: 'netWgt', 271121: 'netWgt'}
# EUR per Comtrade unit -> EUR per DLS unit
DLS_UNIT_FACTOR = {382450: 2400.0,      # concrete: kg -> m3 (2,400 kg/m3)
                   271121: 0.75,        # natural gas: kg -> m3 (~0.75 kg/m3)
                   271600: 1 / 1000}    # electricity: 1000 kWh -> kWh
# Items whose sheet price is kept: trade prices do not represent them
DLS_KEEP_SHEET_PRICE = {
    'tap water': 'HS 220110 is bottled mineral water (0.28 EUR/l), ~700x a utility tariff',
    'wastewater, from residence': 'HS 382520 (sewage sludge) not in the download and not a service price',
}
# Mapping corrections found when checking the download
DLS_HS_FIX = {'chicken for slaughtering, live weight': 10594}   # 010511 = chicks <= 185 g
EUR_PER_USD = 0.9013                           # ECB 2015 annual average
DLS_GAS_ITEM = 'natural gas, high pressure'    # its direct combustion is added to the CO2 threshold
# Capacity check: DLS demand on an origin above FACTOR x its 2015 output is bought with the world
# origin mix. 1.0 = main (DLS CO2: world 1.64 t, energy 19 GJ per person); None = no check
# (world 3.73 t, max 37 t in ID from near-empty sectors with spurious intensities).
DLS_CAPACITY_FACTOR = 1.0
GAS_EF_KG_PER_M3 = 2.0                         # IPCC 2006 default 56.1 t CO2/TJ x ~36 MJ/m3

#%% Indicators and sensitivities ----------------------------------------------------------
WEIGHTING = 'population'                       # main: each person counts once
SENSITIVITY_WEIGHTING = 'country'              # sensitivity: each country counts once
TERRITORIAL_SENSITIVITY = True                 # EG/LE also with territorial (production) accounting

# Normative sensitivity: ranges shown as whiskers on the radar
SENS_TAX_RATES = [0.25, 0.5, 0.75]             # LE tax rate
SENS_BUDGETS = ['planetary_boundary', 'current_world_average']
# 'current_world_average' = equal share of today's world total (BAU), i.e. equality without
# the planetary-boundary ceiling; applies to the EG budget and the LE threshold.

#%% Validation (07) -----------------------------------------------------------------------
DLS_GAS_GJ_PER_M3 = 0.036                      # net calorific value of natural gas
# (study, quantity, value per capita, regional range, mobility, technology, energy type, comparable?)
# 'derived' = computed from the paper's sector figures, not stated by the authors.
DLS_LITERATURE = [
    ('Millward-Hopkins et al. 2020', 'Final energy', 15.3, '13.0-18.4', 'included (~3 GJ)',
     '2050, best available', 'final', 'upper bound for ours: they assume best technology'),
    ('Millward-Hopkins et al. 2020', 'Final energy without mobility (derived)', 12.3, '', 'excluded',
     '2050, best available', 'final', 'closest scope; technology more efficient than 2015'),
    ('Kikstra et al. 2021', 'Final energy, 2050 (156 EJ / 9.2 bn)', 17.0, '9-36 (regions)', 'included',
     'current', 'final', 'same technology logic; uses EXIOBASE for some items'),
    ('Kikstra et al. 2021', 'Final energy without transport (derived)', 9.9, '', 'excluded',
     'current', 'final', 'closest scope with current technology'),
    ('Rao et al. 2019 (in Millward-Hopkins 2020)', 'Final energy (India, Brazil, South Africa)', '12-24', '', 'included',
     'current', 'final', 'order of magnitude'),
    ("O'Neill et al. 2018", 'CO2 boundary (not a DLS value)', 1.61, '', '-', '2011 population', 't CO2',
     'basic needs need ~1.5x the boundary in their data'),
    ("O'Neill et al. 2018", 'Blue water boundary (not a DLS value)', 574, '', '-', '2011 population', 'm3', 'boundary'),
]
